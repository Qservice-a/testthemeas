<?php
$active_tab_license   = $_GET['page'] == 'wescle_settings' ? 'nav-tab-active' : '';
$active_tab_blocks    = $_GET['page'] == 'wescle_settings_customizer' ? 'nav-tab-active' : '';
$active_tab_layouts   = $_GET['page'] == 'wescle_layouts' ? 'nav-tab-active' : '';
$active_tab_export    = $_GET['page'] == 'wescle_export_import' ? 'nav-tab-active' : '';
$active_tab_permalink = $_GET['page'] == 'wescle_permalink' ? 'nav-tab-active' : '';
?>
<nav class="nav-tab-wrapper woo-nav-tab-wrapper">
    <a href="<?php echo admin_url( 'options-general.php?page=wescle_settings' ); ?>" class="nav-tab <?php echo $active_tab_license; ?>"><?php _e( 'Лицензия', 'wescle' ); ?></a>
    <a href="<?php echo admin_url( 'options-general.php?page=wescle_settings_customizer' ); ?>" class="nav-tab <?php echo $active_tab_blocks; ?>"><?php _e( 'Блоки', 'wescle' ); ?></a>
    <!--<a href="<?php echo admin_url( 'options-general.php?page=wescle_layouts' ); ?>" class="nav-tab <?php echo $active_tab_layouts; ?>"><?php _e( 'Шаблоны', 'wescle' ); ?></a>-->
    <a href="<?php echo admin_url( 'options-general.php?page=wescle_export_import' ); ?>" class="nav-tab <?php echo $active_tab_export; ?>"><?php _e( 'Экспорт / Импорт', 'wescle' ); ?> <sup style="color:red;display:inline-block;margin-top: -5px;">beta</sup></a>
    <a href="<?php echo admin_url( 'options-general.php?page=wescle_permalink' ); ?>" class="nav-tab <?php echo $active_tab_permalink; ?>"><?php _e( 'Постоянные ссылки', 'wescle' ); ?></a>
</nav>