<div class="post-course__col">
    <div class="post-course__post post-course-post post">
        <div class="post__image">
			<?php echo wp_get_attachment_image( get_post_thumbnail_id(), 'medium' ); ?>
        </div>
        <div class="post__body">
			<?php course_card_category(); ?>
            <a class="post__title" href="<?php the_permalink(); ?>">
                <div class="title"><?php the_title(); ?></div>
            </a>
            <div class="post__text"><?php post_card_excerpt( 200 ); ?></div>
	        <?php
	        $post_card_meta = [ 'course_duration', 'count_lessons', 'course_lang' ];
	        post_card_meta( $post_card_meta, true, false, false );
	        ?>
        </div>
        <div class="post__inner-body">
		    <?php
		    if ( get_theme_mod( 'course_rating_enabled', true ) ) {
			    $rating = get_post_meta( $post->ID, 'rating', 1 );
			    if ( $rating ) {
				    $rating_width = ( ( $rating / 5 ) * 100 ) . '%';
				    ?>
                    <div class="_rating">
                        <div class="star-rating"><span style="width:<?php echo $rating_width; ?>"><?php _e( 'Рейтинг', 'wescle' ); ?><strong class="rating"><?php echo $rating; ?></strong><?php _e( 'из 5 на основе опроса', 'wescle' ); ?></span></div>
                    </div>
				    <?php
			    }
		    }
		    ?>
            <a class="btn btn-main btn-main_blue" href="<?php the_permalink(); ?>"><?php _e( 'Посмотреть', 'wescle' ); ?></a>
        </div>
    </div>
</div>