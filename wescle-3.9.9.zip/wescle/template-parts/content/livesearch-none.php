<div class="wescle-livesearch__item">
    <div class="wescle-livesearch__title_text"><?php _e( 'Ничего не найдено', 'wescle' ); ?></div>
</div>