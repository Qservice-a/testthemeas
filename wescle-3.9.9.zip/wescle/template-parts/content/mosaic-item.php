<?php
$custom_class = get_post_meta( $post->ID, 'type', 1 );
if ( $custom_class ) {
	$custom_class = ' _' . $custom_class;
}
$label = get_post_meta( $post->ID, 'label', 1 );
$url   = get_post_meta( $post->ID, 'url', 1 );
$title = $post->post_title;
?>
<a class="wescle-places-item<?php echo $custom_class; ?>" href="<?php echo $url; ?>">
	<?php if ( $label ) { ?>
        <div class="wescle-places-item__label"><?php echo $label; ?></div>
	<?php } ?>
    <div class="wescle-places-item__count"><?php echo $title; ?></div>
	<?php echo wp_get_attachment_image( get_post_thumbnail_id(), 'medium_large' ); ?>
</a>