<?php if ( $email = get_theme_mod( 'header_bar_email' ) ) { ?>
    <a class="header-top__mail" href="mailto:<?php echo $email; ?>">
        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16.982" height="12.987" viewbox="0 0 16.982 12.987">
            <path d="M8.009,5.993.018,1.951V1a.953.953,0,0,1,.3-.71A.972.972,0,0,1,1.017,0H15a.972.972,0,0,1,.7.289A.953.953,0,0,1,16,1v.952Zm-.5,1h1L16,3.106v7.882a1.012,1.012,0,0,1-1,1H1.017a.96.96,0,0,1-.7-.3.96.96,0,0,1-.3-.7V3.106Z" transform="translate(0.482 0.5)" fill="#ffffff"></path>
        </svg>
        <span><?php echo $email; ?></span>
    </a>
<?php } ?>