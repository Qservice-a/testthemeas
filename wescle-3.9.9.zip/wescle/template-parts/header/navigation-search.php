<?php
if ( Helper::is_header_store_center() ) {
	return;
}
?>

<?php if ( get_theme_mod( 'header_search', true ) ) { ?>
	<?php
	$div_class = 'navigation__search';
	if ( get_theme_mod( 'header_search_move_burger' ) ) {
		$div_class .= ' _transfer-to-burger';
	}
	?>
    <div class="<?php echo $div_class; ?>">
        <a class="btn-search" href="#">
            <svg class="icon-search" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 24 24">
                <path d="M10 18a7.952 7.952 0 0 0 4.897-1.688l4.396 4.396l1.414-1.414l-4.396-4.396A7.952 7.952 0 0 0 18 10c0-4.411-3.589-8-8-8s-8 3.589-8 8s3.589 8 8 8zm0-14c3.309 0 6 2.691 6 6s-2.691 6-6 6s-6-2.691-6-6s2.691-6 6-6z" fill="#626262"></path>
            </svg>
        </a>
		<?php
		if ( ! Helper::is_header_oneline() ) {
			if ( 'menu' === Helper::get_header_search_type() || 'menu_visible' === Helper::get_header_search_type() ) {
				get_template_part( 'template-parts/header/navigation', 'search-form' );
			}
		}
		?>
    </div>
<?php } ?>

<?php if ( ! Helper::is_header_oneline() && ! Helper::is_header_tabs() ) { ?>
	<?php
	$block_active = true;
	if ( get_theme_mod( 'top_bar_enabled' ) && get_theme_mod( 'top_bar_store_enabled' ) ) {
		$block_active = false;
	}
	if ( $block_active ) {
		get_template_part( 'template-parts/header/navigation', 'store' );
	}
	?>
<?php } ?>
