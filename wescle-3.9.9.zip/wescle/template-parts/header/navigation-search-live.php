<div id="wescle-livesearch" class="wescle-livesearch">
    <div class="wescle-livesearch__items"></div>
</div>