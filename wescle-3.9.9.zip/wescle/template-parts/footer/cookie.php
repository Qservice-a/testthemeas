<?php if ( get_theme_mod( 'cookie_banner_enabled', false ) ) { ?>
	<?php if ( $text = get_theme_mod( 'cookie_banner_text', '' ) ) { ?>
		<?php
		$bg_color = get_theme_mod( 'cookie_banner_bg', '#0088cc' );
		$style    = 'style="display:none;';
		if ( $bg_color != '#0088cc' ) {
			$style .= 'background-color:' . $bg_color;
		}
		$style .= '"';

		$text = preg_replace( "/<p[^>]*?>/", "", $text );
		$text = str_replace( "</p>", "<br>", $text );
		$text = preg_replace( '/(<br>)+$/', '', $text );
		?>
        <div class="coockies" <?php echo $style; ?>>
            <div class="coockies__message"><?php echo $text; ?></div>
            <button class="btn btn-main" data-close><?php echo get_theme_mod( 'cookie_banner_button_label', __( 'Закрыть', 'wescle' ) ); ?></button>
        </div>
	<?php } ?>
<?php } ?>