<?php
$addit_class = get_theme_mod( 'footer_block_classes_text' );
$footer_text = get_theme_mod( 'footer_text' );
if ( $footer_text ) { ?>
    <div class="footer__text <?php echo $addit_class; ?>">
        <p><?php echo nl2br( $footer_text ); ?></p>
    </div>
<?php } ?>

