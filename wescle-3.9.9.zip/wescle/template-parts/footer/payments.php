<?php
$addit_class   = get_theme_mod( 'footer_block_classes_payments' );
$footer_images = get_theme_mod( 'footer_images', [] );
if ( $footer_images ) { ?>
    <ul class="_payments-list <?php echo $addit_class; ?>">
		<?php
		foreach ( $footer_images as $item ) {
			if ( ! $item['image'] ) {
				continue;
			}

			$img = wp_get_attachment_image( $item['image'], 'medium' );
			if ( ! $img ) {
				continue;
			}

			if ( $item['button_link'] ) {
				$img = '<span class="js-link" data-link="' . $item['button_link'] . '">' . $img . '</span>';
			}
			else {
				$img = '<span>' . $img . '</span>';
			}

			echo '<li>' . $img . '</li>';
		}
		?>
    </ul>
<?php } ?>

