(function ($) {
    // Codes here.
})(jQuery);