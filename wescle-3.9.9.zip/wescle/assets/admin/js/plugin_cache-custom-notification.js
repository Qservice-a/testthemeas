(function ($) {

    'use strict';

    wp.customize.bind('ready', function () {
        wp.customize.notifications.add(
            'plugin_cache-custom-notification',
            new wp.customize.Notification(
                'plugin_cache-custom-notification', {
                    dismissible: true,
                    message: app_custom_notification.msg,
                    type: 'info'
                }
            )
        );
    });

})(jQuery);