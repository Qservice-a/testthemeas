jQuery(document).ready(function ($) {
    function menu_media_upload(button_class) {
        jQuery('body').on('click', button_class, function (e) {
            var button = jQuery(this);
            var menu_id = jQuery(this).attr('data-id');

            custom_uploader = wp.media({
                library: {
                    type: 'image'
                },
                button: {},
                multiple: false
            }).on('select', function () { // it also has "open" and "close" events
                var attachment = custom_uploader.state().get('selection').first().toJSON();

                jQuery('.content').show();
                if (jQuery('.menu-block-' + menu_id).length > 0) {
                    jQuery('.upload-image-' + menu_id).remove();
                    jQuery('.menu-block-' + menu_id).append('<img class="menu-image upload-image-' + menu_id + '" src="' + attachment.url + '" width="100" height="100">');
                } else {
                    var html = '<div class="menu-img-block menu-block-' + menu_id + '">';
                    html += '<ul class="menu-actions">';
                    html += '<li><a href="javascript:void(0);" class="edit-btn" id="upload-image-' + menu_id + '" data-id="' + menu_id + '"><span class="dashicons dashicons-update"></a></li>';
                    html += '<li><a href="javascript:void(0);" class="delete-btn"><span class="dashicons dashicons-trash"></a></li>';
                    html += '</ul>';
                    html += '<img class="menu-image upload-image-' + menu_id + '" src="' + attachment.url + '" width="100" height="100">';
                    html += '</div>';
                    jQuery('#upload-image-' + menu_id).before(html);
                }
                jQuery('div.menu-img-block').css('display', 'block');
                jQuery('.img_txt-' + menu_id).val(attachment.id);
                jQuery('.custom_media_url').trigger("change");
            }).open();

            return false;
        });
    }

    menu_media_upload('.upload-image');
    menu_media_upload('.edit-btn');

    jQuery('body').on('click', '.wescle-custom_fields .delete-btn', function (e) {
        e.preventDefault();
        jQuery(this).parent('div.menu-actions').siblings('.menu-image').remove();
        jQuery(this).parents('div.menu-img-block').css('display', 'none');
        var menu_id = jQuery(this).attr('data-id');
        jQuery('.img_txt-' + menu_id).val('');
        jQuery.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {action: 'wescle_delete_menu_image', menu_id: menu_id},
            success: function (data) {
            }
        });
    });
});