<?php
$theme_uri = get_template_directory_uri();

$data = [
	'default' => [
		'title' => __( 'Преимущества', 'wescle-demo' ),
		'items' => [
			[
				'title' => __( 'Возврат и обмен', 'wescle-demo' ),
				'text'  => __( 'в течении 14 дней', 'wescle-demo' ),
				'link'  => '',
				'image' => [
					'url' => $theme_uri . '/includes/demo/advantages/icon1.svg',
					'alt' => '',
					'id'  => '',
				]
			],
			[
				'title' => __( 'Бонусная система', 'wescle-demo' ),
				'text'  => __( 'действует с первой покупки', 'wescle-demo' ),
				'link'  => '',
				'image' => [
					'url' => $theme_uri . '/includes/demo/advantages/icon2.svg',
					'alt' => '',
					'id'  => '',
				]
			],
			[
				'title' => __( 'Предзаказ', 'wescle-demo' ),
				'text'  => __( 'товаров до 5 дней', 'wescle-demo' ),
				'link'  => '',
				'image' => [
					'url' => $theme_uri . '/includes/demo/advantages/icon3.svg',
					'alt' => '',
					'id'  => '',
				]
			],
			[
				'title' => __( 'Удобная доставка', 'wescle-demo' ),
				'text'  => __( 'в любую точку страны', 'wescle-demo' ),
				'link'  => '#payments',
				'image' => [
					'url' => $theme_uri . '/includes/demo/advantages/icon4.svg',
					'alt' => '',
					'id'  => '',
				]
			]
		],
		'settings' => [
			'home_advantages_maxwidth' => 55
		]
	]
];