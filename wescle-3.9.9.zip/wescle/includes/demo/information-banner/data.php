<?php
$theme_uri = get_template_directory_uri();

$data = [
	'default' => [
		'title'    => __( 'Универсальная тема для WordPress', 'wescle-demo' ),
		'text'     => __( 'SEO оптимизированная тема для WordPress, подойдет под любой тип сайта, адаптируется под все экраны (резиновый шаблон), огромная функциональность.', 'wescle-demo' ),
		'settings' => [
			'info_plus_banner_image' => [
				'url' => $theme_uri . '/includes/demo/information-banner/wescle-wordpress.jpg',
				'alt' => '',
				'id'  => '',
			],
		]
	]
];
