<?php
$theme_uri = get_template_directory_uri();

$data = [
	'default' => [
		'title'        => __( 'Было - стало', 'wescle-demo' ),
		'text'         => __( 'Мы предоставляем вашему вниманию нашу работу как это выглядело ранее, и что мы модернизировали на сегодня.', 'wescle-demo' ),
		'image_before' => [
			'url' => $theme_uri . '/includes/demo/difference/before.jpg',
			'alt' => '',
			'id'  => '',
		],
		'image_after'  => [
			'url' => $theme_uri . '/includes/demo/difference/after.jpg',
			'alt' => '',
			'id'  => '',
		],
		'settings'     => [

		]
	]
];