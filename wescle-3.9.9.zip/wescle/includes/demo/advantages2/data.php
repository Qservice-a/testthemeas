<?php
$theme_uri = get_template_directory_uri();

$data = [
	'default' => [
		'title'    => __( 'Преимущества Wescle', 'wescle-demo' ),
		'items'    => [
			[
				'title' => __( 'Настройте внешний вид сайта', 'wescle-demo' ),
				'text'  => __( 'Полная свобода настроек – меню, заголовки, промо-блоки, текст, сам макет… Всё это доступно в лёгком визуальном редакторе.', 'wescle-demo' ),
				'image' => [
					'url' => $theme_uri . '/includes/demo/advantages2/circle-wescle-color.jpg',
					'alt' => '',
					'id'  => '',
				]
			],
			[
				'title' => __( 'Управляйте', 'wescle-demo' ),
				'text'  => __( 'Не надо знать ничего из кодирования, чтобы эффективно настроить внешний вид и дизайн!', 'wescle-demo' ),
				'image' => [
					'url' => $theme_uri . '/includes/demo/advantages2/circle-wescle-color.jpg',
					'alt' => '',
					'id'  => '',
				]
			],
			[
				'title' => __( 'Хэдер и футер преклоняются пред вами', 'wescle-demo' ),
				'text'  => __( 'Станьте безраздельным властелином шапки и подвала сайта, меняя и добавляя информацию по своему усмотрению: баннеры, слайдеры, меню, телефоны, линки на соцсети и многое другое уже готовы стать на одно колено пред вами.', 'wescle-demo' ),
				'image' => [
					'url' => $theme_uri . '/includes/demo/advantages2/circle-wescle-color.jpg',
					'alt' => '',
					'id'  => '',
				]
			],
			[
				'title' => __( 'Доп. модули – это мясо вашего бизнеса', 'wescle-demo' ),
				'text'  => __( 'Мелкие, но меткие – они все будут служить вам денно и нощно: кукисы, schema, лайтбоксы, breadcrumbs, счётчики, поделиться, on/off содержание, преднастройки…', 'wescle-demo' ),
				'image' => [
					'url' => $theme_uri . '/includes/demo/advantages2/circle-wescle-color.jpg',
					'alt' => '',
					'id'  => '',
				]
			]
		],
		'settings' => [
			'home_advantages_v2_image'              => [
				'url' => $theme_uri . '/includes/demo/advantages2/center-wescle-benefits.png',
				'alt' => '',
				'id'  => '',
			],
			'home_advantages_v2_gradient_1'         => '#dd3333',
			'home_advantages_v2_gradient_2'         => '#eeee22',
			'home_advantages_v2_opacity'            => '40',
			'home_advantages_v2_blur'               => '80',
			'home_advantages_v2_items_gradient'     => '#81d742',
			'home_advantages_v2_items_opacity'      => '30',
			'home_advantages_v2_items_border_width' => '10',
			'home_advantages_v2_color_bg'           => '#d7e4f3'
		]
	]
];