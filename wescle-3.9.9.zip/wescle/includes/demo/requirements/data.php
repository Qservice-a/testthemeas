<?php
$theme_uri = get_template_directory_uri();

$list = [
	__( '360 + кастомизации', 'wescle-demo' ),
	__( 'Тема сразу готова к SEO-продвижению', 'wescle-demo' ),
	__( 'Высокие баллы Google PageSpeed', 'wescle-demo' ),
	__( 'Адаптируется под все экраны', 'wescle-demo' ),
	__( 'Огромная функциональность', 'wescle-demo' ),
	__( 'Нет фреймворков, плагинов', 'wescle-demo' ),
	__( 'Кто приобрёл Wescle, могут запросить новый функционал', 'wescle-demo' ),
	__( 'Генератор Landing-ов', 'wescle-demo' ),
	__( 'Блоки Gutenberg 40+', 'wescle-demo' ),
];

$data = [
	'default' => [
		'items' => [
			[
				'title'        => __( 'Характеристики продукта', 'wescle-demo' ),
				'block_align'  => 'left',
				'list'         => $list,
				'youtube_url'  => '',
				'button_label' => __( 'Подробнее', 'wescle-demo' ),
				'button_link'  => '#1',
				'image'        => [
					'url' => $theme_uri . '/includes/demo/requirements/image-charact.jpg',
					'alt' => '',
					'id'  => '',
				]
			],
			[
				'title'        => __( 'Характеристика с видео вставкой', 'wescle-demo' ),
				'block_align'  => 'right',
				'list'         => $list,
				'youtube_url'  => 'https://youtu.be/dnybQFKkstg',
				'button_label' => __( 'Купить сейчас', 'wescle-demo' ),
				'button_link'  => '#2',
				'image'        => [
					'url' => $theme_uri . '/includes/demo/requirements/image-charact2.jpg',
					'alt' => '',
					'id'  => '',
				]
			],
		],
	]
];

