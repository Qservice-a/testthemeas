<?php
$theme_uri = get_template_directory_uri();

$data = [
	'default' => [
		'title'    => __( 'Команда А+', 'wescle-demo' ),
		'text'     => __( '<p>«Каждый шаг, движение рисует наше сегодня, но чтобы научиться правильно держать кисть в руке нам нужен наставник»</p><p>~CEO Wescle</p>', 'wescle-demo' ),
		'items'    => [
			[
				'title'    => __( 'Ольга', 'wescle-demo' ),
				'position' => __( 'СЕО | Город', 'wescle-demo' ),
				'text'     => __( 'Работает в нашей команде уже более 7 лет, активный участник разработки', 'wescle-demo' ),
				'image'    => [
					'url' => $theme_uri . '/includes/demo/team/image-team-wescle.jpg',
					'alt' => '',
					'id'  => '',
				]
			],
			[
				'title'    => __( 'Анна', 'wescle-demo' ),
				'position' => __( 'СЕО | Город', 'wescle-demo' ),
				'text'     => __( 'Работает в нашей команде уже более 7 лет, активный участник разработки', 'wescle-demo' ),
				'image'    => [
					'url' => $theme_uri . '/includes/demo/team/image-team-wescle.jpg',
					'alt' => '',
					'id'  => '',
				]
			]
		],
		'settings' => [
		]
	]
];