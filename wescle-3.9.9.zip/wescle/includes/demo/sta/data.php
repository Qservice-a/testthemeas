<?php
$theme_uri = get_template_directory_uri();

$data = [
	'default' => [
		'title'    => __( 'Все возможно!', 'wescle-demo' ),
		'text'     => __( "Мы любим то, чем мы занимаемся, и мы верим, что каждый может начать делать что-то новое в любом возрасте, находясь в любой стране и будучи в любом социальном статусе. Измените свою жизнь! И помните, что на качество изменений влияете только вы!", 'wescle-demo' ),
		'buttons'  => [
			[
				'label'       => __( 'Узнать больше', 'wescle-demo' ),
				'url'         => '#modal-call',
				'button_view' => ''
			],
			[
				'label'       => __( 'Купить сейчас', 'wescle-demo' ),
				'url'         => '#modal-call',
				'button_view' => 'bg'
			]
		],
		'settings' => [
			'home_sta_bg_image' => [
				'url' => $theme_uri . '/includes/demo/sta/bgobject.svg',
				'alt' => '',
				'id'  => '',
			],
		]
	]
];