<?php
$theme_uri = get_template_directory_uri();

$data = [
	'default' => [
		'title'       => __( 'Сравнение почему Wescle', 'wescle-demo' ),
		'items_plus'  => [
			[
				'text' => __( 'Собственные виджеты чата, SEO, попап окон, баннеров', 'wescle-demo' ),
			],
			[
				'text' => __( 'Лендинги без ограничений на базе Gutenberg', 'wescle-demo' ),
			],
			[
				'text' => __( 'Встроенный оптимизатор PageSpeed', 'wescle-demo' ),
			],
		],
		'items_minus' => [
			[
				'text' => __( 'Установка плагинов, для дополнительного функционала', 'wescle-demo' ),
			],
			[
				'text' => __( 'Установка конструкторов сайта (El, Be, Di...)', 'wescle-demo' ),
			],
			[
				'text' => __( 'Установка плагинов minify css, js, html', 'wescle-demo' ),
			],
		],
		'settings'    => [
			'home_checklist_title_plus'  => __( 'За', 'wescle-demo' ),
			'home_checklist_title_minus' => __( 'Против', 'wescle-demo' ),
		]
	]
];