<?php
$theme_uri = get_template_directory_uri();

$data = [
	'default' => [
		'title'    => __( 'Команда А+', 'wescle-demo' ),
		'text'     => __( '<p>«Каждый шаг, движение рисует наше сегодня, но чтобы научиться правильно держать кисть в руке нам нужен наставник»</p><p>~CEO Wescle</p>', 'wescle-demo' ),
		'items'    => [
			[
				'title'        => __( 'Ольга', 'wescle-demo' ),
				'position'     => __( 'CEO', 'wescle-demo' ),
				'text'         => __( 'Руководитель проекта', 'wescle-demo' ),
				'email'        => 'info@wescle.com',
				'phone'        => '+1000000000',
				'link_vk'      => '#',
				'link_fb'      => '#',
				'link_inst'    => '#',
				'link_twitter' => '#',
				'image'        => [
					'url' => $theme_uri . '/includes/demo/team/image-team-wescle.jpg',
					'alt' => '',
					'id'  => '',
				]
			],
			[
				'title'        => __( 'Анна', 'wescle-demo' ),
				'position'     => __( 'CEO', 'wescle-demo' ),
				'text'         => __( 'Начальник ИТ отдела', 'wescle-demo' ),
				'email'        => 'info@wescle.com',
				'phone'        => '+2000000000',
				'link_vk'      => '#',
				'link_fb'      => '#',
				'link_inst'    => '#',
				'link_twitter' => '#',
				'image'        => [
					'url' => $theme_uri . '/includes/demo/team/image-team-wescle.jpg',
					'alt' => '',
					'id'  => '',
				]
			],
			[
				'title'        => __( 'Катерина', 'wescle-demo' ),
				'position'     => __( 'CEO', 'wescle-demo' ),
				'text'         => __( 'Руководитель SMM', 'wescle-demo' ),
				'email'        => 'info@wescle.com',
				'phone'        => '+3000000000',
				'link_vk'      => '#',
				'link_fb'      => '#',
				'link_inst'    => '#',
				'link_twitter' => '#',
				'image'        => [
					'url' => $theme_uri . '/includes/demo/team/image-team-wescle.jpg',
					'alt' => '',
					'id'  => '',
				]
			],
			[
				'title'        => __( 'Валерия', 'wescle-demo' ),
				'position'     => __( 'CEO', 'wescle-demo' ),
				'text'         => __( 'Начальник SEO отдела', 'wescle-demo' ),
				'email'        => 'info@wescle.com',
				'phone'        => '+4000000000',
				'link_vk'      => '#',
				'link_fb'      => '#',
				'link_inst'    => '#',
				'link_twitter' => '#',
				'image'        => [
					'url' => $theme_uri . '/includes/demo/team/image-team-wescle.jpg',
					'alt' => '',
					'id'  => '',
				]
			]
		],
		'settings' => [
			'home_team_settings_count' => 4,
			'home_team_settings_speed' => 8,
		]
	]
];