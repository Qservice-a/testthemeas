<?php

class Tariff {

	protected $post_type = 'tariff_wescle';

	public function __construct() {
		add_action( 'init', [ $this, 'register_post_type' ] );
	}

	public function register_post_type() {

		$labels = array(
			'name'               => _x( 'Тарифы', 'Post Type General Name', 'wescle' ),
			'singular_name'      => _x( 'Тариф', 'Post Type Singular Name', 'wescle' ),
			'menu_name'          => __( 'Тарифы', 'wescle' ),
			'name_admin_bar'     => __( 'Тариф', 'wescle' ),
			'all_items'          => __( 'Все тарифы', 'wescle' ),
			'add_new_item'       => __( 'Добавить новый тариф', 'wescle' ),
			'add_new'            => __( 'Добавить тариф', 'wescle' ),
			'new_item'           => __( 'Новый тариф', 'wescle' ),
			'edit_item'          => __( 'Редактировать тариф', 'wescle' ),
			'update_item'        => __( 'Обновить тариф', 'wescle' ),
			'view_item'          => __( 'Просмотреть тариф', 'wescle' ),
			'search_items'       => __( 'Найти тариф', 'wescle' ),
			'not_found'          => __( 'Не найдено', 'wescle' ),
			'not_found_in_trash' => __( 'В корзине пусто', 'wescle' ),
		);

		$args = array(
			'label'             => __( 'Тариф', 'wescle' ),
			'labels'            => $labels,
			'supports'          => array( 'title', 'editor', 'page-attributes' ),
			'show_in_rest'      => false, // Add Gutenberg Support
			'hierarchical'      => false,
			'public'            => false,
			'show_ui'           => true,
			'show_in_menu'      => true,
			'menu_position'     => 5,
			'show_in_admin_bar' => true,
			'show_in_nav_menus' => false,
			'can_export'        => true,
			'capability_type'   => 'post',
			'menu_icon'         => 'dashicons-money-alt',
		);
		$args = apply_filters( 'wescle_cpt_' . $this->post_type . '_args', $args );

		register_post_type( $this->post_type, $args );

		$args_tax = array(
			'hierarchical'      => true,
			'labels'            => array(
				'name'          => _x( 'Категории тарифов', 'taxonomy general name', 'wescle' ),
				'singular_name' => _x( 'Категория тарифов', 'taxonomy singular name', 'wescle' ),
				'add_new_item'  => __( 'Добавить новую категорию', 'wescle' ),
				'new_item_name' => __( 'Новая категория тарифов', 'wescle' ),
			),
			'public'            => false,
			'show_ui'           => true,
			'show_in_rest'      => true,
			'query_var'         => true,
			'show_admin_column' => true,
		);
		$args_tax = apply_filters( 'wescle_cpt_tariffcat_wescle_args', $args_tax );

		register_taxonomy(
			'tariffcat_wescle',
			array( $this->post_type ),
			$args_tax
		);
	}
}