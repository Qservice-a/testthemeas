<?php class WsclPermalink{private $menu_slug=THEME_SLUG.'_permalink';private $permalink_data=[];private $isset_custom_permalink=false;public function __construct(){add_action('admin_menu',array($this,'add_admin_menu'));add_action('init',array($this,'save_settings'),1);add_action('init',array($this,'filter_permalink'),5);add_filter('generate_rewrite_rules',array($this,'extends_rewrite'),90);add_action('pre_get_posts',array($this,'parse_pre_get_posts'));add_action('post_type_link',array($this,'change_post_type_link'),10,2);add_filter("template_redirect",array($this,'old_post_link_redirect'),10,3);add_filter("request",array($this,'change_cpt_request'),1,1);add_filter("term_link",array($this,'change_term_permalink'),10,3);add_filter("template_redirect",array($this,'old_term_redirect'),10,3);add_filter("request",array($this,'change_term_request'),1,1);}public function add_admin_menu(){add_submenu_page(null,__('Постоянные ссылки','wescle'),__('Постоянные ссылки','wescle'),'manage_options',$this->menu_slug,array($this,'page_template'));}public function page_template(){if(!current_user_can('manage_options')){wp_die(__('У вас недостаточно прав для доступа к этой странице.','wescle'));}$permalink_default=$this->permalink_data; ?>
        <div class="wrap">
			<?php include get_template_directory().'/template-parts/admin/settings-header.php' ?>
            <div class="_site-settings">
				<?php include get_template_directory().'/template-parts/admin/settings-navigation.php' ?>
                <div class="_site-settings__grid">
                    <div class="_site-settings__content">
                        <h2><?php _e('Постоянные ссылки от темы','wescle'); ?></h2>
                        <form action="?page=<?php echo $this->menu_slug; ?>&saved=1" method="post">
                            <table class="form-table" role="presentation">
                                <tbody>
                                <tr>
                                    <th scope="row"><?php _e('Префикс url для услуг','wescle'); ?></th>
                                    <td>
                                        <input type="text" name="permalink[cpt][service]" value="<?php echo $permalink_default['cpt']['service']; ?>" class="regular-text code">
                                        <p class="description">custom post type: <code>service</code></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Префикс url для категорий услуг','wescle'); ?></th>
                                    <td>
                                        <input type="text" name="permalink[tax][service_cat]" value="<?php echo $permalink_default['tax']['service_cat']; ?>" class="regular-text code">
                                        <p class="description">taxonomy: <code>service_cat</code></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Префикс url для портфолио работ','wescle'); ?></th>
                                    <td>
                                        <input type="text" name="permalink[cpt][portfolio_wescle]" value="<?php echo $permalink_default['cpt']['portfolio_wescle']; ?>" class="regular-text code">
                                        <p class="description">custom post type: <code>portfolio_wescle</code></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Префикс url для метки портфолио','wescle'); ?></th>
                                    <td>
                                        <input type="text" name="permalink[tax][portfolio_tag]" value="<?php echo $permalink_default['tax']['portfolio_tag']; ?>" class="regular-text code">
                                        <p class="description">taxonomy: <code>portfolio_tag</code></p>
                                    </td>
                                </tr>

                                <tr>
                                    <th scope="row"><?php _e('Префикс url для мероприятия','wescle'); ?></th>
                                    <td>
                                        <input type="text" name="permalink[cpt][event_wescle]" value="<?php echo $permalink_default['cpt']['event_wescle']; ?>" class="regular-text code">
                                        <p class="description">custom post type: <code>event_wescle</code></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Префикс url для товаров / услуг','wescle'); ?></th>
                                    <td>
                                        <input type="text" name="permalink[cpt][product_wescle]" value="<?php echo $permalink_default['cpt']['product_wescle']; ?>" class="regular-text code">
                                        <p class="description">custom post type: <code>product_wescle</code></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Префикс url для категорий товаров','wescle'); ?></th>
                                    <td>
                                        <input type="text" name="permalink[tax][productcat_wescle]" value="<?php echo $permalink_default['tax']['productcat_wescle']; ?>" class="regular-text code">
                                        <p class="description">taxonomy: <code>productcat_wescle</code></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Префикс url для видео','wescle'); ?></th>
                                    <td>
                                        <input type="text" name="permalink[cpt][video_wescle]" value="<?php echo $permalink_default['cpt']['video_wescle']; ?>" class="regular-text code">
                                        <p class="description">custom post type: <code>video_wescle</code></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Префикс url для категорий товаров','wescle'); ?></th>
                                    <td>
                                        <input type="text" name="permalink[tax][videocat_wescle]" value="<?php echo $permalink_default['tax']['videocat_wescle']; ?>" class="regular-text code">
                                        <p class="description">taxonomy: <code>videocat_wescle</code></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php _e('Префикс url для команды','wescle'); ?></th>
                                    <td>
                                        <input type="text" name="permalink[cpt][team_wescle]" value="<?php echo $permalink_default['cpt']['team_wescle']; ?>" class="regular-text code">
                                        <p class="description">custom post type: <code>team_wescle</code></p>
                                    </td>
                                </tr>
                                <?php if(get_theme_mod('woo_brands_enabled')){ ?>
                                    <tr>
                                        <th scope="row"><?php _e('Префикс url для брендов','wescle'); ?></th>
                                        <td>
                                            <input type="text" name="permalink[tax][product_brand]" value="<?php echo $permalink_default['tax']['product_brand']; ?>" class="regular-text code">
                                            <p class="description">taxonomy: <code>product_brand</code></p>
                                        </td>
                                    </tr>
                                <?php } ?>
                                <?php if(get_theme_mod('module_catalog_enabled')){ ?>
                                    <tr>
                                        <th scope="row"><?php _e('Префикс url для элемента каталога','wescle'); ?></th>
                                        <td>
                                            <input type="text" name="permalink[cpt][catalog_item]" value="<?php echo $permalink_default['cpt']['catalog_item']; ?>" class="regular-text code">
                                            <p class="description">custom post type: <code>catalog_item</code></p>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row" colspan="2"><label><?php _e('Постоянные ссылки элемента каталога','wescle'); ?></label></th>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label><input name="permalink[structure][cpt][catalog_item]" type="radio" value="" <?php checked('',$permalink_default['structure']['cpt']['catalog_item']); ?> class="regular-text code"> <?php _e('По умолчанию','wescle'); ?></label></th>
                                        <td>
                                            <code class="non-default-example"><?php echo esc_html(home_url()); ?>/<?php echo $permalink_default['cpt']['catalog_item']; ?>/sample-catalog-item/</code>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label><input name="permalink[structure][cpt][catalog_item]" type="radio" value="remove_slug" <?php checked('remove_slug',$permalink_default['structure']['cpt']['catalog_item']); ?> class="regular-text code"> <?php _e('Без SLUG','wescle'); ?></label></th>
                                        <td>
                                            <code class="non-default-example"><?php echo esc_html(home_url()); ?>/sample-catalog-item/</code>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label><input name="permalink[structure][cpt][catalog_item]" type="radio" value="category-single" <?php checked('category-single',$permalink_default['structure']['cpt']['catalog_item']); ?> class="regular-text code"> <?php _e('C категорией','wescle'); ?></label></th>
                                        <td>
                                            <code class="non-default-example"><?php echo esc_html(home_url()); ?>/<?php echo $permalink_default['tax']['catalogcat_wescle']; ?>/sample-catalog-item/</code>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><?php _e('Префикс url для категорий каталога','wescle'); ?></th>
                                        <td>
                                            <input type="text" name="permalink[tax][catalogcat_wescle]" value="<?php echo $permalink_default['tax']['catalogcat_wescle']; ?>" class="regular-text code">
                                            <p class="description">taxonomy: <code>catalogcat_wescle</code></p>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row" colspan="2"><label><?php _e('Постоянные ссылки категорий каталога','wescle'); ?></label></th>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label><input name="permalink[structure][tax][catalogcat_wescle]" type="radio" value="" <?php checked('',$permalink_default['structure']['tax']['catalogcat_wescle']); ?> class="regular-text code"> <?php _e('По умолчанию','wescle'); ?></label></th>
                                        <td>
                                            <code class="non-default-example"><?php echo esc_html(home_url()); ?>/<?php echo $permalink_default['tax']['catalogcat_wescle']; ?>/sample-category/</code>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label><input name="permalink[structure][tax][catalogcat_wescle]" type="radio" value="remove_slug" <?php checked('remove_slug',$permalink_default['structure']['tax']['catalogcat_wescle']); ?> class="regular-text code"> <?php _e('Без SLUG категории','wescle'); ?></label></th>
                                        <td>
                                            <code class="non-default-example"><?php echo esc_html(home_url()); ?>/sample-category/</code>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th colspan="2">
                                            <div class="wescle-notice wescle-notice-error">
                                                <p><strong><?php _e('Предупреждение','wescle'); ?>:</strong> <?php _e('вам нужно быть осторожным, чтобы не конфликтовали текущие ссылки с постоянными ссылками, и вам нужно знать, в каком порядке правила идут первыми. Вы были предупреждены!','wescle'); ?></p>
                                            </div>
			                                <?php if(function_exists('yoast_breadcrumb')){$wpseo_titles=get_option('wpseo_titles');if($wpseo_titles['breadcrumbs-enable']){ ?>
                                                    <div class="wescle-notice">
                                                        <p><?php _e('Если вы изменили постоянные ссылки каталога и элементы каталога уже были опубликованы, следуйте приведенным ниже инструкциям:','wescle'); ?></p>
                                                        <p>1) <?php _e('Установите плагин Yoast Test Helper, который можно найти здесь','wescle'); ?> <a href="https://wordpress.org/plugins/yoast-test-helper/" target="_blank" rel="noopener noreferrer nofollow">https://wordpress.org/plugins/yoast-test-helper/</a><br>
                                                            2) <?php _e('Перейдите в Инструменты','wescle'); ?> → Yoast Test<br>
                                                            3) <?php printf(__('Нажмите кнопку %s','wescle'),'<code>Reset Indexables tables &amp; migrations</code>'); ?><br>
                                                            4) <?php _e('Перейдите в SEO → Инструменты','wescle'); ?><br>
                                                            5) <?php _e('Нажмите кнопку <code>Начать оптимизацию SEO-данных</code> и дождитесь завершения','wescle'); ?>
                                                        </p>
                                                    </div>
					                                <?php }} ?>
                                        </th>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
	                        <?php submit_button(); ?>
                            <input type="hidden" name="save_wescle_permalink" value="1">
                        </form>
                    </div>

                </div>
            </div>
	        <?php include get_template_directory().'/template-parts/admin/settings-footer.php' ?>
        </div>
		<?php }public function save_settings(){$this->permalink_data=self::get_permalink_data();if(!isset($_POST['save_wescle_permalink'])){return;}$wescle_permalink=$_POST['permalink']??[];foreach($wescle_permalink as $key=>$items){foreach($items as $key_item=>$value){if(!$value){unset($wescle_permalink[$key][$key_item]);}}}$wescle_permalink_result=[];$wescle_permalink_result['cpt']=array_merge($this->permalink_data['cpt'],$wescle_permalink['cpt']);$wescle_permalink_result['tax']=array_merge($this->permalink_data['tax'],$wescle_permalink['tax']);if(isset($wescle_permalink['structure'])){$wescle_permalink_result['structure']=array_merge($this->permalink_data['structure'],$wescle_permalink['structure']);}update_option('wescle_permalink',$wescle_permalink_result,1);$this->permalink_data=self::get_permalink_data();flush_rewrite_rules(false);}public static function get_permalink_data(){$permalink_data=['cpt'=>['service'=>'service','portfolio_wescle'=>'portfolio','event_wescle'=>'event','product_wescle'=>'prod_wescle','video_wescle'=>'video','team_wescle'=>'team_wescle','catalog_item'=>'catalog-item',],'tax'=>['service_cat'=>'service-category','portfolio_tag'=>'portfolio-tag','productcat_wescle'=>Helper::is_woocommerce_active()?'wescle-prod':'prod-category','videocat_wescle'=>'video-category','product_brand'=>'product_brand','catalogcat_wescle'=>'catalog-category',],'structure'=>['cpt'=>['catalog_item'=>''],'tax'=>['catalogcat_wescle'=>'',],]];$wescle_permalink=get_option('wescle_permalink',[]);if($wescle_permalink){$permalink_data['cpt']=array_merge($permalink_data['cpt'],$wescle_permalink['cpt']);$permalink_data['tax']=array_merge($permalink_data['tax'],$wescle_permalink['tax']);if(isset($wescle_permalink['structure'])){$permalink_data['structure']=array_merge($permalink_data['structure'],$wescle_permalink['structure']);}}return $permalink_data;}public static function get_structure_data($key_data=''){$structure_data=['cpt'=>[],'tax'=>[],];$permalink_data=self::get_permalink_data();foreach($permalink_data['structure']['cpt']as $post_type=>$val){if($val){$structure_data['cpt'][$post_type]=$val;}}foreach($permalink_data['structure']['tax']as $tax=>$val){if($val){$structure_data['tax'][$tax]=$val;}}if($key_data){$structure_data=$structure_data[$key_data];}return $structure_data;}public function filter_permalink(){foreach($this->permalink_data['cpt']as $key=>$slug){add_filter('wescle_cpt_'.$key.'_args',function($args,$post_type){if(isset($this->permalink_data['cpt'][$post_type])&&$this->permalink_data['cpt'][$post_type]){$args['rewrite']['slug']=$this->permalink_data['cpt'][$post_type];}return $args;},5,2);}foreach($this->permalink_data['tax']as $key=>$slug){add_filter('wescle_cpt_'.$key.'_args',function($args,$taxonomy){if(isset($this->permalink_data['tax'][$taxonomy])&&$this->permalink_data['tax'][$taxonomy]){$args['rewrite']['slug']=$this->permalink_data['tax'][$taxonomy];}return $args;},5,2);}}static function get_taxonomy_for_cpt($post_type){$data=['catalog_item'=>'catalogcat_wescle',];return $data[$post_type]?? false;}function extends_rewrite($wp_rewrite){$structure_data=self::get_structure_data('tax');$structure_cpt=self::get_structure_data('cpt');foreach($structure_cpt as $post_type=>$value){if('category-single'==$value){$taxonomy=self::get_taxonomy_for_cpt($post_type);if($taxonomy){$structure_data[$taxonomy]='extends_from_single';}}}if($structure_data){$feed_rules=[];foreach($structure_data as $tax=>$value){$feed_rules['(.+)']='index.php?'.$tax.'='.$wp_rewrite->preg_index(1);}$wp_rewrite->rules=$wp_rewrite->rules+$feed_rules;}}public function parse_pre_get_posts($query){if(!$query->is_main_query()||2!=count($query->query)||!isset($query->query['page'])){return;}$structure_data=self::get_structure_data('cpt');if($structure_data){$post_type=array_merge(['post','page'],array_keys($structure_data));if(!empty($query->query['name'])){$query->set('post_type',$post_type);}elseif(!empty($query->query['pagename'])&&false===strpos($query->query['pagename'],'/')){$query->set('post_type',$post_type);$query->set('name',$query->query['pagename']);}}}public function change_post_type_link($post_link,$post){if('publish'!=$post->post_status){return $post_link;}$structure_data=self::get_structure_data('cpt');if(!$structure_data){return $post_link;}if(!in_array($post->post_type,array_keys($structure_data))){return $post_link;}$permalink_data=self::get_permalink_data();foreach($structure_data as $post_type=>$value){if($post->post_type==$post_type){$replace='/';$taxonomy=self::get_taxonomy_for_cpt($post_type);if(!$taxonomy){$taxonomy='no_tax';}if('category-single'==$value){$terms=get_the_terms($post,$taxonomy);if(!empty($terms)){$parents_list=get_term_parents_list($terms[0]->term_id,$taxonomy,['format'=>'slug','link'=>false]);$replace.=$parents_list;}}$custom_post_type=$permalink_data['cpt'][$post_type];$post_link=str_replace('/'.$custom_post_type.'/',$replace,$post_link);break;}}return $post_link;}function old_post_link_redirect(){$structure_cpt=self::get_structure_data('cpt');if($structure_cpt){$permalink_data=self::get_permalink_data();$cpt=array_keys($structure_cpt);foreach($cpt as $post_type){$cpt_slug=$permalink_data['cpt'][$post_type];if(strpos($_SERVER["REQUEST_URI"],$cpt_slug)===false){continue;}if(is_singular($post_type)){wp_redirect(site_url(str_replace($cpt_slug,"",$_SERVER["REQUEST_URI"])),301);exit();}}}}function change_cpt_request($query){if(is_admin()){return $query;}$structure_cpt=self::get_structure_data('cpt');if(!$structure_cpt){return $query;}$taxonomies=[];$structure_tax=self::get_structure_data('tax');if($structure_tax){$taxonomies=array_keys($structure_tax);}foreach($structure_cpt as $post_type=>$value){if('category-single'==$value){$taxonomy=self::get_taxonomy_for_cpt($post_type);if($taxonomy){$taxonomies[]=$taxonomy;}}}if(isset($query["attachment"])){$name=$query["attachment"];}else{$name=(isset($query["name"]))?$query["name"]:null;if(!$name&&strpos(get_option('permalink_structure'),'/%category%/')===0){$name=(isset($query["category_name"]))?$query["category_name"]:null;}}if($name===null){foreach($taxonomies as $taxonomy){$name=$query[$taxonomy]?? '';if($name){$names=explode('/',$name);$name=end($names);break;}}}if($name){$post_id=self::get_post_id_by_slug($name);if($post_id){unset($query["attachment"]);unset($query["category_name"]);if(isset($taxonomy)){unset($query[$taxonomy]);}$query['page']='';$query['name']=$name;$this->isset_custom_permalink=true;}}return $query;}private static function get_post_id_by_slug($post_slug,$post_types=[]){global $wpdb;$sql_post_type='';if($post_types){$sql_post_type="post_type IN ('".implode("','",$post_types)."') AND";}$post_id=$wpdb->get_var($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE post_name=%s AND $sql_post_type post_status='publish' LIMIT 1",$post_slug));return $post_id;}public function change_term_permalink($url,$term,$taxonomy){$structure_tax=self::get_structure_data('tax');if($structure_tax){$permalink_data=self::get_permalink_data();$taxonomies=array_keys($structure_tax);foreach($taxonomies as $taxonomy_name){$taxonomy_slug=$permalink_data['tax'][$taxonomy_name];if(strpos($url,$taxonomy_slug)===false||$taxonomy!=$taxonomy_name){continue;}$url=str_replace("/".$taxonomy_slug,"",$url);break;}}return $url;}function old_term_redirect(){$structure_tax=self::get_structure_data('tax');if($structure_tax){$permalink_data=self::get_permalink_data();$taxonomies=array_keys($structure_tax);foreach($taxonomies as $taxonomy_name){$taxonomy_slug=$permalink_data['tax'][$taxonomy_name];if(strpos($_SERVER["REQUEST_URI"],$taxonomy_slug)===false){continue;}if(is_tax($taxonomy_name)){wp_redirect(site_url(str_replace($taxonomy_slug,"",$_SERVER["REQUEST_URI"])),301);exit();}}}}public function change_term_request($query){if(is_admin()){return $query;}if($this->isset_custom_permalink){return $query;}$structure_tax=self::get_structure_data('tax');if(!$structure_tax){return $query;}$taxonomies=array_keys($structure_tax);foreach($taxonomies as $taxonomy_name){if(isset($query["attachment"])){$include_children=true;$name=$query["attachment"];}else{$include_children=false;$name=(isset($query["name"]))?$query["name"]:null;if(!$name&&strpos(get_option('permalink_structure'),'/%category%/')===0){$name=(isset($query["category_name"]))?$query["category_name"]:null;}}if($name){$term=get_term_by("slug",$name,$taxonomy_name);if($term&&!is_wp_error($term)){if($include_children){unset($query["attachment"]);$parent=$term->parent;while($parent){$parent_term=get_term($parent,$taxonomy_name);$name=$parent_term->slug."/".$name;$parent=$parent_term->parent;}}else{unset($query["name"]);}switch($taxonomy_name){default:unset($query['category_name']);$query[$taxonomy_name]=$name;}break;}}}return $query;}}new WsclPermalink();