<?php class WsclMenuImage{public function __construct(){add_action('admin_enqueue_scripts',array($this,'enqueue_scripts'));add_filter('wp_nav_menu_item_custom_fields',array($this,'custom_fields'),10,2);add_action('wp_update_nav_menu_item',array($this,'update_custom_fields'),10,3);add_action('wp_ajax_wescle_delete_menu_image',array($this,'delete_menu_image'));}public function enqueue_scripts(){global $pagenow;if('nav-menus.php'!==$pagenow){return;}$style_version=THEME_VERSION;if(defined('WP_DEBUG')&&true===WP_DEBUG){$style_version=time();}wp_enqueue_media();wp_enqueue_script(THEME_SLUG.'-menu-image',get_template_directory_uri().'/assets/admin/js/menu-image.js',array('jquery'),$style_version,true);$data=array('theme_uri'=>get_template_directory_uri());wp_localize_script(THEME_SLUG.'-menu-image','menu_image_data',$data);}public function custom_fields($item_id,$menu_item){wp_nonce_field('wescle_menu_custom_fields','_wescle_menu_custom_fields_nonce');$menu_image_id=get_post_meta($item_id,'wescle_menu_item_image',true);$menu_image=wp_get_attachment_url($menu_image_id); ?>
        <div class="wescle-custom_fields description description-wide">
            <div class="menu-img">
                <label for="upload-image-<?php echo $item_id; ?>"><?php _e('Иконка','wescle'); ?></label>
                <br>
				<?php if($menu_image){ ?>
                    <div class="menu-img-block menu-block-<?php echo $item_id; ?>">
                        <ul class="menu-actions">
                            <li><a href="javascript:void(0);" class="edit-btn" id="upload-image-<?php echo $item_id; ?>" data-id="<?php echo $item_id; ?>"><span class="dashicons dashicons-update"></span></a></li>
                            <li><a href="javascript:void(0);" class="delete-btn" data-id="<?php echo $item_id; ?>"><span class="dashicons dashicons-trash"></span></a></li>
                        </ul>
                        <img class="menu-image upload-image-<?php echo $item_id; ?>" src="<?php echo $menu_image; ?>" width="100" height="100">
                    </div>
				<?php } ?>
                <input class="widefat custom_media_url img_txt-<?php echo $item_id; ?>" id="edit-menu-item-image-<?php echo $item_id; ?>" name="wescle_menu_item_image[<?php echo $item_id; ?>]" type="hidden" value="<?php echo $menu_image_id; ?>">
                <input type="button" class="button upload-image" data-id="<?php echo $item_id; ?>" id="upload-image-<?php echo $item_id; ?>" value="<?php _e('Загрузить','wescle'); ?>"/>
            </div>
        </div>
		<?php }public function update_custom_fields($menu_id,$menu_item_db_id,$args){if(!isset($_POST['_wescle_menu_custom_fields_nonce'])||!wp_verify_nonce($_POST['_wescle_menu_custom_fields_nonce'],'wescle_menu_custom_fields')){return $menu_id;}if(is_array($_REQUEST['wescle_menu_item_image'])){$image_value=sanitize_text_field($_REQUEST['wescle_menu_item_image'][$menu_item_db_id]);if($image_value){update_post_meta($menu_item_db_id,'wescle_menu_item_image',$image_value);}}}function delete_menu_image(){delete_post_meta(sanitize_text_field($_POST['menu_id']),'wescle_menu_item_image');exit;}}new WsclMenuImage();