<?php class WsclWooAjaxAddCart{public function __construct(){add_action('wp_footer',array($this,'product_page_ajax_add_to_cart_js'),100);add_action('wc_ajax_wescle_add_to_cart',array($this,'ajax_add_to_cart_handler'));add_action('wc_ajax_nopriv_wescle_add_to_cart',array($this,'ajax_add_to_cart_handler'));if(!isset($_GET['add-to-cart'])){remove_action('wp_loaded',array('WC_Form_Handler','add_to_cart_action'),20);}add_filter('woocommerce_add_to_cart_fragments',array($this,'ajax_add_to_cart_add_fragments'));}function product_page_ajax_add_to_cart_js(){global $product;$is_active=false;if(is_page()&&get_theme_mod('product_quick_view_enabled')){$is_active=true;}if(is_singular('product')&&!$product->is_type('external')){$is_active=true;}if(Helper::is_woocommerce()&&!is_singular('product')){$is_active=true;}if(is_cart()){$is_active=true;}if(!$is_active){return;} ?>
        <style>
          form.cart .added_to_cart {
            display: none;
          }

          .popup_wescle form.cart .added_to_cart {
            display: block;
          }
        </style>
        <script>
            jQuery(function ($) {
                $('body').on('submit', 'form.cart', function (e) {
                    if ($(this).closest('.product').hasClass('product-type-external')) {
                        return true;
                    }

                    e.preventDefault();

                    var form = $(this);
                    form.block({message: null, overlayCSS: {background: '#fff', opacity: 0.6}});

                    var formData = new FormData(form[0]);
                    formData.append('add-to-cart', form.find('[name=add-to-cart]').val());

                    // Ajax action.
                    $.ajax({
                        url: wc_add_to_cart_params.wc_ajax_url.toString().replace('%%endpoint%%', 'wescle_add_to_cart'),
                        data: formData,
                        type: 'POST',
                        processData: false,
                        contentType: false,
                        complete: function (response) {
                            response = response.responseJSON;

                            if (!response) {
                                return;
                            }

                            console.log(response);

                            if (response.error && response.product_url) {
                                window.location = response.product_url;
                                return;
                            }

                            // Redirect to cart option
                            if (wc_add_to_cart_params.cart_redirect_after_add === 'yes') {
                                window.location = wc_add_to_cart_params.cart_url;
                                return;
                            }

                            var $thisbutton = form.find('.single_add_to_cart_button'); //

                            // Trigger event so themes can refresh other areas.
                            $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, $thisbutton]);
                            update_product_cart_from_fragments();

                            // Remove existing notices
                            $('.woocommerce-error, .woocommerce-message, .woocommerce-info').remove();

                            // Add new notices
                            form.closest('.goods').find('.woocommerce-notices-wrapper').html(response.fragments.notices_html)

                            form.unblock();

                            if (server_data.cart_auto_open === '1') {
                                $('#modal-product').removeClass('is-active');
                            }
                        }
                    });
                });
            });
        </script>
		<?php }function ajax_add_to_cart_handler(){WC_Form_Handler::add_to_cart_action();WC_AJAX::get_refreshed_fragments();}function ajax_add_to_cart_add_fragments($fragments){$all_notices=WC()->session->get('wc_notices',array());$notice_types=apply_filters('woocommerce_notice_types',array('error','success','notice'));ob_start();foreach($notice_types as $notice_type){if(wc_notice_count($notice_type)>0){wc_get_template("notices/{$notice_type}.php",array('notices'=>array_filter($all_notices[$notice_type]),));}}$fragments['notices_html']=ob_get_clean();wc_clear_notices();return $fragments;}}new WsclWooAjaxAddCart();