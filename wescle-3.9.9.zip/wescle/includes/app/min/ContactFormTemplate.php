<?php class ContactFormTemplate{protected $option_key=THEME_SLUG.'_installed_forms';public $forms=[];public function __construct(){$this->forms=['subscribe-footer'=>__('Подписаться - Footer','wescle'),'subscribe-sidebar'=>__('Подписаться - Widget','wescle'),'callback'=>__('Модальное окно - Заказать звонок','wescle'),'order'=>__('Контактная форма после контента','wescle'),'home_contact'=>__('Блок "Контакты"','wescle'),'home_left_time'=>__('Блок "Специальное предложение"','wescle'),'home_price_table'=>__('Бронирование пакета','wescle'),'home_price_tariff'=>__('Бронирование прайса','wescle'),'home_licenses'=>__('Покупка лицензии','wescle'),'home_tariff'=>__('Покупка тарифа','wescle'),'popup'=>__('Форма для модального окна','wescle'),'home_team_cpt'=>__('Задать вопрос сотруднику','wescle'),'home_catalog_item'=>__('Форма для каталога','wescle'),];add_action('wpcf7_admin_init',array($this,'wpcf7_add_forms'),15);add_action('before_delete_post',array($this,'before_delete_post'),15);add_filter('wpcf7_contact_form_default_pack',array($this,'wpcf7_contact_form_properties'),15,2);}public function get_forms(){return $this->forms;}public function wpcf7_add_forms(){if(isset($_GET['wpcf7_add_forms'])){return;}$is_add_form=false;$installed_forms=get_option($this->option_key);if(!$installed_forms){$installed_forms=[];}foreach($this->forms as $form_key=>$form_title){if(!isset($installed_forms[$form_key])){$is_add_form=true;break;}}if(!$is_add_form){return;}foreach($this->get_forms()as $form_key=>$form_title){if(isset($installed_forms[$form_key])){continue;}$contact_form=\WPCF7_ContactForm::get_template(array('title'=>$form_title,));$contact_form->save();$installed_forms[$form_key]=$contact_form->id();$key_theme_mod='';$cf7_id=$contact_form->id();if($form_key=='subscribe-footer'){$key_theme_mod='footer_subscribe_cf7';}elseif($form_key=='callback'){$key_theme_mod='callback_сf7';}elseif($form_key=='order'){$key_theme_mod='';set_theme_mod('post_cf7_after_content',(string) $cf7_id);set_theme_mod('page_cf7_after_content',(string) $cf7_id);set_theme_mod('service_cf7_after_content',(string) $cf7_id);}elseif($form_key=='home_contact'){$key_theme_mod='home_contact_cf7';}elseif($form_key=='home_left_time'){$key_theme_mod='home_special_cf7';}elseif($form_key=='home_price_table'){$key_theme_mod='home_price_table_cf7';}elseif($form_key=='home_licenses'){$key_theme_mod='home_licenses_cf7';}elseif($form_key=='home_tariff'){$key_theme_mod='home_tariff_cf7';}elseif($form_key=='home_team_cpt'){$key_theme_mod='home_team_cpt_cf7';}elseif($form_key=='home_catalog_item'){$key_theme_mod='home_catalog_item_cf7';}if($key_theme_mod){set_theme_mod($key_theme_mod,(string) $cf7_id);}}update_option($this->option_key,$installed_forms,true);wp_redirect(admin_url('?wpcf7_add_forms=1'));exit;}public function wpcf7_contact_form_properties($contact_form,$args){foreach($this->get_forms()as $form_key=>$form_title){if($form_title==$contact_form->title()){$properties=$contact_form->get_properties();$properties['form']=self::get_form_prop($properties['form'],$form_key.'-form');$properties['mail']=self::get_form_prop($properties['mail'],$form_key.'-mail');$contact_form->set_properties($properties);}}return $contact_form;}public static function get_form_prop($template,$prop){if('subscribe-footer-form'==$prop){$template=self::subscribe_footer_form();}elseif('subscribe-footer-mail'==$prop){$template=self::subscribe_mail();}elseif('subscribe-sidebar-form'==$prop){$template=self::subscribe_sidebar_form();}elseif('subscribe-sidebar-mail'==$prop){$template=self::subscribe_mail();}elseif('callback-form'==$prop){$template=self::callback_form();}elseif('callback-mail'==$prop){$template=self::callback_mail();}elseif('order-form'==$prop){$template=self::order_form();}elseif('order-mail'==$prop){$template=self::order_mail();}elseif('home_contact-form'==$prop){$template=self::home_contact_form();}elseif('home_contact-mail'==$prop){$template=self::home_contact_mail();}elseif('home_left_time-form'==$prop){$template=self::home_left_time_form();}elseif('home_left_time-mail'==$prop){$template=self::home_left_time_mail();}elseif('home_price_table-form'==$prop){$template=self::home_price_table_form();}elseif('home_price_table-mail'==$prop){$template=self::home_price_table_mail();}elseif('home_price_tariff-form'==$prop){$template=self::home_price_tariff_form();}elseif('home_price_tariff-mail'==$prop){$template=self::home_price_tariff_mail();}elseif('home_licenses-form'==$prop){$template=self::home_licenses_form();}elseif('home_licenses-mail'==$prop){$template=self::home_licenses_mail();}elseif('home_tariff-form'==$prop){$template=self::home_tariff_form();}elseif('home_tariff-mail'==$prop){$template=self::home_tariff_mail();}elseif('popup-form'==$prop){$template=self::modal_popup_form();}elseif('popup-mail'==$prop){$template=self::modal_popup_mail();}elseif('home_team_cpt-form'==$prop){$template=self::modal_home_team_cpt_form();}elseif('home_team_cpt-mail'==$prop){$template=self::modal_home_team_cpt_mail();}elseif('home_catalog_item-form'==$prop){$template=self::modal_home_catalog_item_form();}elseif('home_catalog_item-mail'==$prop){$template=self::modal_home_catalog_item_mail();}return $template;}public static function subscribe_footer_form(){$template=sprintf('<div class="form-subscribe">
	<div class="form-subscribe__input">[email* your-email class:form-input placeholder "E-mail"]</div>
	[submit class:form-subscribe__btn class:btn class:btn-main class:btn-main_blue "%1$s"]
</div>',__('Подписаться','wescle'));return trim($template);}public static function subscribe_sidebar_form(){$template=sprintf('[email* your-email class:newsletter__input class:form-input placeholder "%1$s"]
[submit class:newsletter__btn class:btn class:btn-main class:btn-main_blue "%2$s"]',__('Ваш email адрес','wescle'),__('Подписаться','wescle'));return trim($template);}public static function callback_form(){$template=sprintf('<div class="form-call-request__title title">%1$s</div>
<div class="form-call-request__text">%2$s</div>
<fieldset class="form-call-request__group">
	<label class="form-label" for="form-call-request-name">%3$s<span> *</span></label>
	[text* your-name class:form-input id:form-call-request-name]
</fieldset>
<fieldset class="form-call-request__group">
	<label class="form-label" for="form-call-request-telephone">%4$s<span> *</span></label>
	[tel* your-tel class:form-input id:form-call-request-telephone]
</fieldset>
<fieldset class="form-call-request__group">
	[acceptance acceptance-529 default:on] %5$s <span class="icon-check"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 16 16"><g fill="#08c"><path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093l3.473-4.425a.236.236 0 0 1 .02-.022z"></path></g></svg></span> [/acceptance]
</fieldset>

<div class="button-submit">
<button class="form-button btn btn-main btn-flare">%6$s</button>
[submit class:d-none class:btn class:btn-main "%6$s"]
</div>',__('Обратный звонок','wescle'),__('Оставьте свои контактные данные и наш оператор свяжется с Вами.','wescle'),__('Имя:','wescle'),__('Телефон:','wescle'),__('Я даю свое согласие на обработку персональных данных в соответствии с <a href="#">Условиями *</a>','wescle'),__('Отправить','wescle'));return trim($template);}public static function order_form(){$template=sprintf('<label> %1$s
    [text* your-name] </label>
    
<label> %2$s
    [tel* your-tel] </label>
    
<label> Email:
    [email your-email] </label>
    
<label> %3$s
    [textarea your-message] </label>
    
[acceptance acceptance-555 default:on] %4$s <span class="icon-check"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 16 16"><g fill="#08c"><path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093l3.473-4.425a.236.236 0 0 1 .02-.022z"></path></g></svg></span> [/acceptance]

[submit class:form-button class:btn class:btn-main "%5$s"]',__('Имя:','wescle'),__('Телефон:','wescle'),__('Сообщение:','wescle'),__('Я даю свое согласие на обработку персональных данных в соответствии с <a href="#">Условиями *</a>','wescle'),__('Отправить','wescle'));return trim($template);}public static function home_contact_form(){$template=sprintf('<label> %1$s*
    [text* your-name] </label>
    
<label> %2$s*
    [tel* your-tel] </label>
    
<label> %3$s:
    [email your-email] </label>
    
<label> %4$s
    [text your-subject] </label>
    
<label class="wpcf7-form__textarea-field"> %5$s
    [textarea your-message] </label>

<div class="button-submit">
<button class="form-button btn btn-main btn-flare">%6$s</button>
[submit class:d-none class:btn class:btn-main "%6$s"]
</div>',__('Имя','wescle'),__('Телефон','wescle'),__('Почта','wescle'),__('Тема','wescle'),__('Ваше сообщение','wescle'),__('Отправить','wescle'));return trim($template);}public static function home_left_time_form(){$template=sprintf('<div class="wpcf7-form__title">%1$s</div>
<label> %2$s
    [text* your-name] </label>
    
<label> %3$s
    [email your-email] </label>
    
<label> %4$s
    [tel* your-tel] </label>
    
[acceptance acceptance-555 default:on] %5$s <span class="icon-check"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 16 16"><g fill="#08c"><path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093l3.473-4.425a.236.236 0 0 1 .02-.022z"></path></g></svg></span> [/acceptance]

<div class="button-submit">
<button class="form-button btn btn-main btn-flare">%6$s</button>
[submit class:d-none class:btn class:btn-main "%6$s"]
</div>',__('Заголовок формы...','wescle'),__('Ваше имя и фамилия','wescle'),__('Ваш email','wescle'),__('Ваш телефон','wescle'),__('Я даю свое согласие на обработку персональных данных в соответствии с <a href="#">Условиями *</a>','wescle'),__('Принять участие','wescle'));return trim($template);}public static function home_price_table_form(){$template=sprintf('<div class="form-call-request__title title">%1$s</div>
<div class="form-call-request__text">%2$s</div>
<fieldset class="form-call-request__group">
	<label class="form-label" for="form-call-price-name">%3$s<span> *</span></label>
	[text* your-name class:form-input id:form-call-price-name]
</fieldset>
<fieldset class="form-call-request__group">
	<label class="form-label" for="form-call-price-telephone">%4$s<span> *</span></label>
	[tel* your-tel class:form-input id:form-call-price-telephone]
</fieldset>
<fieldset class="form-call-request__group">
	[acceptance acceptance-529 default:on] %5$s <span class="icon-check"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 16 16"><g fill="#08c"><path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093l3.473-4.425a.236.236 0 0 1 .02-.022z"></path></g></svg></span> [/acceptance]
</fieldset>
[hidden package_name class:d-none id:input-package_name]
[submit class:form-button class:btn class:btn-main "%6$s"]',__('Бронирование пакета','wescle'),__('Оставьте свои контактные данные и наш оператор свяжется с Вами.','wescle'),__('Имя:','wescle'),__('Телефон:','wescle'),__('Я даю свое согласие на обработку персональных данных в соответствии с <a href="#">Условиями *</a>','wescle'),__('Отправить','wescle'));return trim($template);}public static function home_price_tariff_form(){$template=sprintf('<div class="form-call-request__title title">%1$s</div>
<div class="form-call-request__text">%2$s</div>
<fieldset class="form-call-request__group">
	<label class="form-label" for="form-call-price_name">%3$s<span> *</span></label>
	[text* your-name class:form-input id:form-call-price_name]
</fieldset>
<fieldset class="form-call-request__group">
	<label class="form-label" for="form-call-price_telephone">%4$s<span> *</span></label>
	[tel* your-tel class:form-input id:form-call-price_telephone]
</fieldset>
<fieldset class="form-call-request__group">
	[acceptance acceptance-529 default:on] %5$s <span class="icon-check"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 16 16"><g fill="#08c"><path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093l3.473-4.425a.236.236 0 0 1 .02-.022z"></path></g></svg></span> [/acceptance]
</fieldset>
[hidden price_name class:d-none id:input-price_name]
[hidden price_value class:d-none id:input-price_value]
[submit class:form-button class:btn class:btn-main "%6$s"]',__('Бронирование прайса','wescle'),__('Оставьте свои контактные данные и наш оператор свяжется с Вами.','wescle'),__('Имя:','wescle'),__('Телефон:','wescle'),__('Я даю свое согласие на обработку персональных данных в соответствии с <a href="#">Условиями *</a>','wescle'),__('Отправить','wescle'));return trim($template);}public static function home_licenses_form(){$template=sprintf('<div class="form-call-request__title title">%1$s</div>
<div class="form-call-request__text">%2$s</div>
<fieldset class="form-call-request__group">
	<label class="form-label" for="form-call-price-license">%3$s<span> *</span></label>
	[text* your-name class:form-input id:form-call-price-license]
</fieldset>
<fieldset class="form-call-request__group">
	<label class="form-label" for="form-call-license-telephone">%4$s<span> *</span></label>
	[tel* your-tel class:form-input id:form-call-license-telephone]
</fieldset>
<fieldset class="form-call-request__group">
	[acceptance acceptance-529 default:on] %5$s <span class="icon-check"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 16 16"><g fill="#08c"><path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093l3.473-4.425a.236.236 0 0 1 .02-.022z"></path></g></svg></span> [/acceptance]
</fieldset>
[hidden license_name class:d-none id:input-license_name]
[submit class:form-button class:btn class:btn-main "%6$s"]',__('Покупка лицензии','wescle'),__('Оставьте свои контактные данные и наш оператор свяжется с Вами.','wescle'),__('Имя:','wescle'),__('Телефон:','wescle'),__('Я даю свое согласие на обработку персональных данных в соответствии с <a href="#">Условиями *</a>','wescle'),__('Отправить','wescle'));return trim($template);}public static function home_tariff_form(){$template=sprintf('<div class="form-call-request__title title">%1$s</div>
<div class="form-call-request__text">%2$s</div>
<fieldset class="form-call-request__group">
	<label class="form-label" for="form-call-tariff-name">%3$s<span> *</span></label>
	[text* your-name class:form-input id:form-call-tariff-name]
</fieldset>
<fieldset class="form-call-request__group">
	<label class="form-label" for="form-call-tariff-telephone">%4$s<span> *</span></label>
	[tel* your-tel class:form-input id:form-call-tariff-telephone]
</fieldset>
<fieldset class="form-call-request__group">
	[acceptance acceptance-529 default:on] %5$s <span class="icon-check"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 16 16"><g fill="#08c"><path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093l3.473-4.425a.236.236 0 0 1 .02-.022z"></path></g></svg></span> [/acceptance]
</fieldset>
[hidden tariff_name class:d-none id:input-tariff_name]
[submit class:form-button class:btn class:btn-main "%6$s"]',__('Покупка тарифа','wescle'),__('Оставьте свои контактные данные и наш оператор свяжется с Вами.','wescle'),__('Имя:','wescle'),__('Телефон:','wescle'),__('Я даю свое согласие на обработку персональных данных в соответствии с <a href="#">Условиями *</a>','wescle'),__('Отправить','wescle'));return trim($template);}public static function modal_popup_form(){$template=sprintf('<label> %1$s
    [text* your-name placeholder "%1$s"] </label>
    
<label> %2$s
    [email* your-email placeholder "%2$s"] </label>
    
[submit class:form-button class:btn class:btn-main "%3$s"]',__('Ваше имя','wescle'),__('Введите свой email','wescle'),__('Присоединиться','wescle'));return trim($template);}public static function modal_home_team_cpt_form(){$template=sprintf('<div class="modal-write-message__title">%1$s</div>
<div class="modal-write-message__description">%2$s</div>
<div class="modal-write-message__form wpcf7-form">
	<label> %3$s*
	    [text* your-name] </label>
	<label> %4$s*
	    [tel* your-tel] </label>
	<label> %5$s
	    [email your-email] </label>
	<label> %6$s
	    [textarea your-service] </label>
	<label> %7$s*
	    [text* your-team] </label>
	<label> %8$s
	    [textarea your-message] </label>
	[acceptance acceptance-529 default:on] %9$s <span class="icon-check"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 16 16"><g fill="#08c"><path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093l3.473-4.425a.236.236 0 0 1 .02-.022z"></path></g></svg></span> [/acceptance]
	<div class="button-submit">
		<button class="form-button btn btn-main btn-flare">%10$s</button>
		[submit class:d-none class:btn class:btn-main "%10$s"]
	</div>
</div>',__('Задать вопрос сотруднику','wescle'),__('Сотрудник компании с радостью ответит на ваши вопросы.','wescle'),__('Ваше имя','wescle'),__('Ваш телефон','wescle'),__('Ваш email','wescle'),__('Интересующая услуга/товар','wescle'),__('Сотрудник','wescle'),__('Ваше сообщение','wescle'),__('Я согласен на обработку персональных данных.','wescle'),__('Отправить','wescle'));return trim($template);}public static function modal_home_catalog_item_form(){$template=sprintf('<div class="_form-transport__title title">%1$s</div>
<div class="_form-transport__text">%2$s</div>
<div class="_form-transport__selected"><div class="_form-transport__label">%14$s:</div><span></span></div>
<div class="_form-transport__item">
[text* your-name class:form-input placeholder "%3$s"]
</div>
<div class="_form-transport__item">
[tel* your-tel class:form-input placeholder "%4$s"]
</div>
<div class="_form-transport__item">
[email your-email class:form-input placeholder "%5$s"]
</div>
<div class="_form-transport__locations _return-place-hide">
	<div class="_form-transport__label">%6$s</div>
[text location-start class:_form-transport__select placeholder "%7$s"]
[text location-end class:_form-transport__select id:return-place-transport placeholder "%8$s"]
	<div class="_form-transport__return">
		<input class="form-checkbox" id="transport-return-toggle" type="checkbox" name="transport-return-toggle" checked>
		<label class="form-label checkbox-label" for="transport-return-toggle"><span>%9$s</span><span class="icon-check">
		  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 16 16">
			<g fill="#08c">
			  <path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093l3.473-4.425a.236.236 0 0 1 .02-.022z"></path>
			</g>
		  </svg> 
	  	</span></label>	  
	</div>
</div>
<div class="_form-transport__period">
	<div class="_form-transport__label">%10$s</div>
[date date-start]
[time time-start]
	<div class="_form-transport__label">%11$s</div>
[date date-end]
[time time-end]
</div>
[acceptance acceptance-500 default:on] %12$s <span class="icon-check"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 16 16"><g fill="#08c"><path fill-rule="evenodd" d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093l3.473-4.425a.236.236 0 0 1 .02-.022z"></path></g></svg></span> [/acceptance]
[submit class:form-button class:btn class:btn-main "%13$s"]
[hidden catalog_item class:input-catalog_item]
[hidden catalog_item_url class:input-catalog_item_url]',__('Параметры','wescle'),__('Lorem ipsum dolor','wescle'),__('Ваше имя, фамилия','wescle'),__('Телефон','wescle'),__('Email','wescle'),__('Локация','wescle'),__('Место подачи','wescle'),__('Место возврата','wescle'),__('Вернуть в том же месте','wescle'),__('Дата и время подачи','wescle'),__('Дата и время возврата','wescle'),__('Я согласен на обработку персональных данных.','wescle'),__('Заказать','wescle'),__('Выбранные параметры','wescle'),);return trim($template);}public static function subscribe_mail(){$template=self::mail();$template['body']=__('Email: ','wescle').'[your-email]'."\n\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function callback_mail(){$template=self::mail();$template['subject']=sprintf(_x('%1$s "Заказ звонка"','mail subject','wescle'),'[_site_title]');$template['body']=__('Имя: ','wescle').'[your-name]'."\n".__('Телефон: ','wescle').'[your-tel]'."\n\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function mail(){$template=array('subject'=>sprintf(_x('%1$s "Подписаться"','mail subject','wescle'),'[_site_title]'),'sender'=>sprintf('%s <%s>','[_site_title]',self::from_email()),'body'=>sprintf(__('От: %s','wescle'),'[your-name] <[your-email]>')."\n".sprintf(__('Тема: %s','wescle'),'[your-subject]')."\n\n".__('Сообщение:','wescle')."\n".'[your-message]'."\n\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]'),'recipient'=>'[_site_admin_email]','additional_headers'=>'','attachments'=>'','use_html'=>0,'exclude_blank'=>0,);return $template;}public static function order_mail(){$template=self::mail();$template['subject']=sprintf(_x('%1$s "Форма со страницы"','mail subject','wescle'),'[_site_title]');$template['body']=__('Имя: ','wescle').'[your-name]'."\n".__('Телефон: ','wescle').'[your-tel]'."\n".__('Email: ','wescle').'[your-email]'."\n\n".__('Сообщение: ','wescle').'[your-message]'."\n\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function home_contact_mail(){$template=self::mail();$template['subject']=sprintf(_x('%1$s "Форма с главной страницы"','mail subject','wescle'),'[_site_title]');$template['body']=__('Имя: ','wescle').'[your-name]'."\n".__('Телефон: ','wescle').'[your-tel]'."\n".__('Email: ','wescle').'[your-email]'."\n\n".__('Тема: ','wescle').'[your-subject]'."\n".__('Сообщение: ','wescle').'[your-message]'."\n\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function home_left_time_mail(){$template=self::mail();$template['subject']=sprintf(_x('%1$s "Специальное предложение"','mail subject','wescle'),'[_site_title]');$template['body']=__('Имя: ','wescle').'[your-name]'."\n".__('Телефон: ','wescle').'[your-tel]'."\n".__('Email: ','wescle').'[your-email]'."\n\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function home_price_table_mail(){$template=self::mail();$template['subject']=sprintf(_x('%1$s "Бронирование пакета"','mail subject','wescle'),'[_site_title]');$template['body']=__('Имя: ','wescle').'[your-name]'."\n".__('Телефон: ','wescle').'[your-tel]'."\n".__('Пакет: ','wescle').'[package_name]'."\n\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function home_price_tariff_mail(){$template=self::mail();$template['subject']=sprintf(_x('%1$s "Бронирование прайса"','mail subject','wescle'),'[_site_title]');$template['body']=__('Имя: ','wescle').'[your-name]'."\n".__('Телефон: ','wescle').'[your-tel]'."\n".__('Прайс/тариф: ','wescle').'[price_name]'."\n".__('Стоимость: ','wescle').'[price_value]'."\n\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function home_licenses_mail(){$template=self::mail();$template['subject']=sprintf(_x('%1$s "Покупка лицензии"','mail subject','wescle'),'[_site_title]');$template['body']=__('Имя: ','wescle').'[your-name]'."\n".__('Телефон: ','wescle').'[your-tel]'."\n".__('Лицензия: ','wescle').'[license_name]'."\n\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function home_tariff_mail(){$template=self::mail();$template['subject']=sprintf(_x('%1$s "Покупка тарифа"','mail subject','wescle'),'[_site_title]');$template['body']=__('Имя: ','wescle').'[your-name]'."\n".__('Телефон: ','wescle').'[your-tel]'."\n".__('Тариф: ','wescle').'[tariff_name]'."\n\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function modal_popup_mail(){$template=self::mail();$template['subject']=sprintf(_x('%1$s "Форма с модального окна"','mail subject','wescle'),'[_site_title]');$template['body']=__('Имя: ','wescle').'[your-name]'."\n".__('Email: ','wescle').'[your-email]'."\n\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function modal_home_team_cpt_mail(){$template=self::mail();$template['subject']=sprintf(_x('%1$s "Задать вопрос сотруднику"','mail subject','wescle'),'[_site_title]');$template['body']=__('Имя: ','wescle').'[your-name]'."\n".__('Телефон: ','wescle').'[your-tel]'."\n".__('Email: ','wescle').'[your-email]'."\n".__('Интересующая услуга/товар: ','wescle').'[your-service]'."\n".__('Сотрудник: ','wescle').'[your-team]'."\n".__('Сообщение: ','wescle').'[your-message]'."\n\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function modal_home_catalog_item_mail(){$template=self::mail();$template['subject']=sprintf(_x('%1$s "Форма с каталога"','mail subject','wescle'),'[_site_title]');$template['body']=__('Имя: ','wescle').'[your-name]'."\n".__('Телефон: ','wescle').'[your-tel]'."\n".__('Email: ','wescle').'[your-email]'."\n".__('Объект каталога: ','wescle').'[catalog_item] | [catalog_item_url]'."\n".__('Место подачи: ','wescle').'[location-start]'."\n".__('Место возврата: ','wescle').'[location-end]'."\n".__('Дата и время подачи: ','wescle').'[date-start] [time-start]'."\n".__('Дата и время возврата: ','wescle').'[date-end] [time-end]'."\n"."\n".sprintf(__('Отправлено со страницы: %1$s','wescle'),'[_url]')."\n".'-- '."\n".sprintf(__('Это сообщение отправлено с сайта %1$s (%2$s)','wescle'),'[_site_title]','[_site_url]');return $template;}public static function from_email(){$admin_email=get_option('admin_email');$sitename=strtolower($_SERVER['SERVER_NAME']);if(wpcf7_is_localhost()){return $admin_email;}if(substr($sitename,0,4)=='www.'){$sitename=substr($sitename,4);}if(strpbrk($admin_email,'@')=='@'.$sitename){return $admin_email;}return 'wordpress@'.$sitename;}public function before_delete_post($postid){$post=get_post($postid);if($post&&$post->post_type=='wpcf7_contact_form'){$installed_forms=get_option($this->option_key);if(!$installed_forms){$installed_forms=[];}foreach($installed_forms as $key=>$form_id){if($form_id==$postid){unset($installed_forms[$key]);}}update_option($this->option_key,$installed_forms);}}}