<?php class WsclTermImage{static $taxes=['category','post_tag','product_tag','portfolio_tag','licensecat_wescle','coursecat_wescle'];static $meta_key='_thumbnail_id';static $add_img_url='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkAQMAAABKLAcXAAAABlBMVEUAAAC7u7s37rVJAAAAAXRSTlMAQObYZgAAACJJREFUOMtjGAV0BvL/G0YMr/4/CDwY0rzBFJ704o0CWgMAvyaRh+c6m54AAAAASUVORK5CYII=';public function __construct(){add_action('admin_init',function(){$taxes=apply_filters('wescle_taxes_thumbnail',self::$taxes);foreach($taxes as $taxname){add_action("{$taxname}_add_form_fields",[$this,'add_term_image']);add_action("{$taxname}_edit_form_fields",[$this,'update_term_image']);add_action("created_{$taxname}",[$this,'save_term_image'],10,2);add_action("edited_{$taxname}",[$this,'updated_term_image'],10,2);add_filter("manage_edit-{$taxname}_columns",[$this,'add_image_column']);add_filter("manage_{$taxname}_custom_column",[$this,'image_column'],10,3);}});add_filter('wescle_admin_server_data',array($this,'custom_server_data'));}public function add_term_image(){wp_enqueue_media();add_action('admin_print_footer_scripts',[$this,'script_upload_image'],99); ?>
        <div class="form-field term-group">
            <label><?php _e('Иконка','wescle'); ?></label>
            <div class="term__image__wrapper">
                <a class="termeta_img_button" href="#">
                    <img src="<?php echo self::$add_img_url  ?>" alt="">
                </a>
                <input type="button" class="button button-secondary termeta_img_remove" value="<?php _e('Удалить','wescle'); ?>"/>

                <input type="hidden" id="term_imgid" class="term_imgid" name="term_imgid" value="">
            </div>
        </div>
		<?php }public function update_term_image($term){wp_enqueue_media();add_action('admin_print_footer_scripts',[$this,'script_upload_image'],99);$image_id=get_term_meta($term->term_id,self::$meta_key,true);$image_url=$image_id?wp_get_attachment_image_url($image_id,'thumbnail'):self::$add_img_url; ?>
        <tr class="form-field term-group-wrap">
            <th scope="row"><?php _e('Иконка','wescle'); ?></th>
            <td>
                <div class="term__image__wrapper">
                    <a class="termeta_img_button" href="#">
						<?php echo '<img src="'.$image_url.'" alt="">'; ?>
                    </a>
                    <input type="button" class="button button-secondary termeta_img_remove" value="<?php _e('Удалить','wescle'); ?>"/>

                    <input type="hidden" id="term_imgid" class="term_imgid" name="term_imgid" value="<?php echo $image_id; ?>">
                </div>
            </td>
        </tr>
		<?php }public function script_upload_image(){ ?>
        <script>
            jQuery(document).ready(function ($) {
                $('.termeta_img_remove').click(function () {
                    setTimeout(function () {
                        $('.term__image__wrapper').find('img').attr('src', '<?php echo self::$add_img_url  ?>');
                    }, 100);
                });
            });
        </script>
		<?php }public function add_image_column($columns){return array_slice($columns,0,1)+['image'=>'']+$columns;}public function image_column($string,$column_name,$term_id){if($column_name=='image'){$image_id=get_term_meta($term_id,self::$meta_key,1);$image='';if($image_id){$image=wp_get_attachment_thumb_url($image_id);}elseif(Helper::is_woocommerce_active()){$image=wc_placeholder_img_src();}if($image){$string='<img src="'.esc_url($image).'" alt="" class="wp-post-image" height="48" width="48" />';}}return $string;}public function save_term_image($term_id,$tt_id){if(isset($_POST['term_imgid'])&&$attach_id=(int) $_POST['term_imgid']){update_term_meta($term_id,self::$meta_key,$attach_id);}}public function updated_term_image($term_id,$tt_id){if(!isset($_POST['term_imgid'])){return;}$cur_term_attach_id=(int) get_term_meta($term_id,self::$meta_key,1);if($attach_id=(int) $_POST['term_imgid']){update_term_meta($term_id,self::$meta_key,$attach_id);if($cur_term_attach_id!=$attach_id){wp_delete_attachment($cur_term_attach_id);}}else{if($cur_term_attach_id){wp_delete_attachment($cur_term_attach_id);}delete_term_meta($term_id,self::$meta_key);}}public function custom_server_data($server_data){global $pagenow;if($pagenow&&in_array($pagenow,['edit-tags.php','term.php'])){$server_data['frame_media_title']=__('Иконка термина','wescle');$server_data['frame_media_button']=__('Задать иконку','wescle');}return $server_data;}}new WsclTermImage();