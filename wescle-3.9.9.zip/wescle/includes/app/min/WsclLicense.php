<?php class WsclLicense{protected $menu_slug=THEME_SLUG.'_settings';protected $settings_name=THEME_SLUG.'_settings';protected $license_key=THEME_SLUG.'_license';protected $license_verify=THEME_SLUG.'_license_verify';protected $license_error=THEME_SLUG.'_license_error';protected $partner_id_key=THEME_SLUG.'_partner_id';public function __construct(){add_action('admin_menu',array($this,'add_admin_menu'));add_action('admin_init',array($this,'save_settings'));}public function add_admin_menu(){add_options_page(__('Настройки сайта','wescle'),__('Настройки сайта','wescle'),'manage_options',$this->menu_slug,array($this,'page_template'));}public function page_template(){if(!current_user_can('manage_options')){wp_die(__('У вас недостаточно прав для доступа к этой странице.','wescle'));} ?>
        <div class="wrap">
			<?php include get_template_directory().'/template-parts/admin/settings-header.php' ?>
            <div class="_site-settings">
				<?php include get_template_directory().'/template-parts/admin/settings-navigation.php' ?>
                <div class="_site-settings__grid">
                    <div class="_site-settings__content">
                        <h2><?php _e('Лицензия','wescle'); ?></h2>
                        <form action="?page=<?php echo $this->menu_slug; ?>&saved=1" method="post">
                            <table class="form-table" role="presentation">
                                <tbody>
                                <tr>
                                    <th scope="row"><?php _e('Лицензионный ключ','wescle'); ?></th>
                                    <td>
										<?php $this->output_license_field(); ?>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
							<?php submit_button(); ?>
                            <input type="hidden" name="save_license_wescle" value="1">
                        </form>
                    </div>

                </div>
            </div>
			<?php include get_template_directory().'/template-parts/admin/settings-footer.php' ?>
        </div>
		<?php }public function save_settings(){if(!isset($_POST['save_license_wescle'])){return;}$val=$_POST['license_wescle'];$api_url=THEME_API_URL;$license=trim($val);$api_params=array('action'=>'activate_license','license'=>$license,'item_name'=>urlencode(THEME_SLUG),'version'=>THEME_VERSION,'type'=>'theme','url'=>home_url(),'ip'=>Helper::get_ip(),);$response=wp_remote_post($api_url,array('timeout'=>60,'sslverify'=>false,'body'=>$api_params));if(is_wp_error($response)){$api_url=str_replace("https","http",$api_url);$response=wp_remote_post($api_url,array('timeout'=>60,'sslverify'=>false,'body'=>$api_params));}if(is_wp_error($response)){update_option($this->license_error,'Server Error | '.json_encode($response));return false;}$license_data=wp_remote_retrieve_body($response);if(substr($license_data,0,2)=='ok'){update_option($this->license_key,$license,true);update_option($this->license_verify,time()+MONTH_IN_SECONDS);delete_option($this->license_error);$license_data_arr=explode('|',$license_data);if($license_data_arr[1]){update_option($this->partner_id_key,$license_data_arr[1]);}$license_data=['latest_check'=>current_time('timestamp'),'error'=>0,];update_option('wescle_license_data',$license_data);}else{delete_option($this->license_key);update_option($this->license_error,$license_data,true);}}public function output_license_field(){$license=get_option($this->license_key,'');$license_error=get_option($this->license_error,'');if(!empty($license_error)){$messages=['error1'=>__('Ошибка запроса. Обратитесь в тех.поддержку','wescle'),'error2'=>__('Лицензионный ключ уже активирован на другом домене.','wescle'),'error3'=>__('Лицензионный ключ не найден.','wescle'),];if(strpos($license_error,'<html')===false){echo '<p style="color:#ff0000;"><strong>'.$messages[$license_error].'</strong></p>';}else{if(strpos($license_error,'Cloudflare')!==false){echo '<p style="color:#ff0000;"><strong>'.__('Cloudflare заблокировал запрос! Обратитесь, пожалуйста, к разработчикам темы!','wescle').'</strong></p>';}else{}}}echo '<input type="text" name="license_wescle" class="regular-text" value="'.esc_attr($license).'">';}}