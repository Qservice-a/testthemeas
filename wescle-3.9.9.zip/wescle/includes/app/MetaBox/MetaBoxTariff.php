<?php

class MetaBoxTariff extends MetaBoxPost {

	protected $labels = [];

	public function __construct() {
		$this->set_settings( array(
			'post_type'      => [ 'tariff_wescle' ],
			'meta_box_title' => __( 'Настройки тарифа', 'wescle' ),
		) );

		$this->labels = [
			'type'              => __( 'Тип', 'wescle' ),
			'type_plus'         => __( 'Преимущество', 'wescle' ),
			'type_minus'        => __( 'Недостаток', 'wescle' ),
			'type_text'         => __( 'Кастомный текст', 'wescle' ),
			'title'             => __( 'Заголовок', 'wescle' ),
			'text'              => __( 'Текст', 'wescle' ),
			'button_remove'     => __( 'Удалить', 'wescle' ),
			'button_add_item'   => __( 'Добавить', 'wescle' ),
			'price_currency'    => __( 'текст перед ценой', 'wescle' ),
			'price_month'       => __( 'Цена в месяц', 'wescle' ),
			'price_month_after' => __( 'текст после цены в месяц', 'wescle' ),
			'price_year'        => __( 'Цена в год', 'wescle' ),
			'price_year_after'  => __( 'текст после цены в год', 'wescle' ),
			'price_custom'      => __( 'Кастомное поле с ценой', 'wescle' ),
			'percent'           => __( 'Процент', 'wescle' ),
			'value'             => __( 'Значение', 'wescle' ),
			'url'               => __( 'URL', 'wescle' ),
			'label_button'      => __( 'Надпись на кнопке', 'wescle' ),
			'url_year'          => __( 'URL (год)', 'wescle' ),
			'label_button_year' => __( 'Надпись на кнопке (год)', 'wescle' ),
		];

		add_action( 'load-post.php', array( $this, 'init' ) );
		add_action( 'load-post-new.php', array( $this, 'init' ) );

		add_action( 'load-post.php', array( $this, 'init_cpt' ) );
		add_action( 'load-post-new.php', array( $this, 'init_cpt' ) );
	}

	public function set_fields() {
		$current_screen = get_current_screen();
		if ( in_array( $current_screen->post_type, $this->post_type ) ) {
			$this->fields = [
				[
					'type'  => 'checkbox',
					'name'  => 'is_special',
					'label' => __( 'Рекомендованный?', 'wescle' ),
				],
				[
					'type'  => 'text',
					'name'  => 'is_special_label',
					'label' => __( 'Надпись для "Рекомендованный"', 'wescle' ),
				],
				[
					'type'  => 'color',
					'name'  => 'color_text',
					'label' => __( 'Цвет текста', 'wescle' ),
				],
				[
					'type'  => 'color',
					'name'  => 'color_bg',
					'label' => __( 'Цвет фона', 'wescle' ),
				],
				[
					'type'  => 'checkbox',
					'name'  => 'slider_ui',
					'label' => __( 'Показывать ползунок с ценами?', 'wescle' ),
				],
				[
					'type'  => 'text_html',
					'name'  => 'currency',
					'label' => __( 'Валюта', 'wescle' ),
				],
				[
					'type'  => 'text_html',
					'name'  => 'slider_ui_min_text',
					'label' => __( 'Надпись для минимум', 'wescle' ),
				],
				[
					'type'  => 'text_html',
					'name'  => 'slider_ui_max_text',
					'label' => __( 'Надпись для максимум', 'wescle' ),
				],
				[
					'type'  => 'text_html',
					'name'  => 'slider_ui_month_text',
					'label' => __( 'текст после значения (в месяц)', 'wescle' ),
				],
				[
					'type'  => 'text_html',
					'name'  => 'slider_ui_year_text',
					'label' => __( 'текст после значения (в год)', 'wescle' ),
				],
				[
					'type'  => 'number',
					'name'  => 'price_month',
					'label' => $this->labels['price_month']
				],
				[
					'type'  => 'text_html',
					'name'  => 'price_month_after',
					'label' => $this->labels['price_month_after']
				],
				[
					'type'  => 'number',
					'name'  => 'price_year',
					'label' => $this->labels['price_year']
				],
				[
					'type'  => 'text_html',
					'name'  => 'price_year_after',
					'label' => $this->labels['price_year_after']
				],
				[
					'type'  => 'text_html',
					'name'  => 'price_custom',
					'label' => $this->labels['price_custom']
				],
				[
					'type'  => 'text',
					'name'  => 'label_button',
					'label' => $this->labels['label_button']
				],
				[
					'type'        => 'text',
					'name'        => 'button_url',
					'label'       => esc_html__( 'Если нужно - то укажите URL для кнопки заказа', 'wescle' ),
					'description' => esc_html__( 'по умолчанию открывается выбранный продукт или модальное окно с формой заказа', 'wescle' )
				],
				[
					'type'    => 'select2',
					'name'    => 'related_product',
					'label'   => __( 'Укажите связь с продуктом', 'wescle' ),
					'options' => Helper::get_posts( array(
						'post_type'      => 'product',
						'posts_per_page' => 200
					), true ),
				],
			];
		}
	}

	public function init_cpt() {
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_action( 'save_post', array( $this, 'save' ) );
	}

	public function add_meta_box( $post_type ) {
		$post_types = array( 'tariff_wescle' );

		if ( in_array( $post_type, $post_types ) ) {
			add_meta_box(
				'wescle_tariff_slider_prices',
				__( 'Данные для ползунка с ценами', 'wescle' ),
				array( $this, 'render_meta_box_prices' ),
				$post_type,
				'advanced',
				'low'
			);

			add_meta_box(
				'wescle_tariff_info',
				__( 'Преимущества и недостатки', 'wescle' ),
				array( $this, 'render_meta_box_content' ),
				$post_type,
				'advanced',
				'low'
			);
		}
	}

	public function save( $post_id ) {

		if ( ! isset( $_POST['wescle_tariff_info_nonce'] ) ) {
			return;
		}

		$nonce = $_POST['wescle_tariff_info_nonce'];

		if ( ! wp_verify_nonce( $nonce, 'wescle_tariff_info' ) ) {
			return;
		}

		// Если это автосохранение ничего не делаем.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Проверяем права пользователя.
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}

		$wescle_tariff_data = $_POST['wescle_tariff_slider_prices'];
		$data               = [];
		if ( $wescle_tariff_data ) {
			foreach ( $wescle_tariff_data['percent'] as $key => $percent ) {
				if ( '' === $percent || ! '' === $wescle_tariff_data['value'][ $key ] ) {
					continue;
				}

				$data[] = [
					'percent'           => $percent,
					'value'             => $wescle_tariff_data['value'][ $key ],
					'url'               => $wescle_tariff_data['url'][ $key ],
					'label_button'      => $wescle_tariff_data['label_button'][ $key ],
					'price_currency'    => $wescle_tariff_data['price_currency'][ $key ],
					'price_month'       => $wescle_tariff_data['price_month'][ $key ],
					'price_month_after' => $wescle_tariff_data['price_month_after'][ $key ],
					'price_year'        => $wescle_tariff_data['price_year'][ $key ],
					'price_year_after'  => $wescle_tariff_data['price_year_after'][ $key ],
					'url_year'          => $wescle_tariff_data['url_year'][ $key ],
					'label_button_year' => $wescle_tariff_data['label_button_year'][ $key ],
				];
			}
		}
		update_post_meta( $post_id, 'wescle_tariff_slider_prices', $data );

		$wescle_tariff_info = $_POST['wescle_tariff_info'];
		$data               = [];
		if ( $wescle_tariff_info ) {
			foreach ( $wescle_tariff_info['title'] as $key => $title ) {
				$type = $wescle_tariff_info['type'][ $key ];
				$text = $wescle_tariff_info['text'][ $key ];

				if ( $title || $text ) {
					$data[] = [
						'type'  => $type,
						'title' => $title,
						'text'  => $text,
					];
				}
			}
		}

		update_post_meta( $post_id, 'wescle_tariff_info', $data );
	}

	public function render_meta_box_prices( $post ) {
		$wescle_tariff_info = get_post_meta( $post->ID, 'wescle_tariff_slider_prices', true );
		?>
        <div class="wescle-metabox">
			<?php wp_nonce_field( 'wescle_tariff_info', 'wescle_tariff_info_nonce' ); ?>

            <div class="wrap-repeater-fields">
                <div class="repeater-fields">
					<?php
					if ( $wescle_tariff_info ) {
						foreach ( $wescle_tariff_info as $item ) {
							?>
                            <div class="repeater-row repeater-row__flex flex-wrap">
                                <div class="repeater-row__flex">
                                    <div class="repeater-field">
                                        <label>
											<?php echo $this->labels['percent']; ?>
                                            <input type="number" class="widefat" name="wescle_tariff_slider_prices[percent][]" value="<?php echo esc_attr( $item['percent'] ); ?>">
                                        </label>
                                    </div>
                                    <div class="repeater-field">
                                        <label>
											<?php echo $this->labels['value']; ?>
                                            <input type="number" class="widefat" name="wescle_tariff_slider_prices[value][]" value="<?php echo esc_attr( $item['value'] ); ?>">
                                        </label>
                                    </div>
                                    <div class="repeater-field">
                                        <label>
											<?php echo $this->labels['price_currency']; ?>
                                            <input type="text" class="widefat" name="wescle_tariff_slider_prices[price_currency][]" value="<?php echo esc_attr( $item['price_currency'] ); ?>">
                                        </label>
                                    </div>
                                    <div class="repeater-field alignright">
                                        <button type="button" class="button-link button-link-delete"><?php echo $this->labels['button_remove']; ?></button>
                                    </div>
                                </div>
                                <div class="repeater-row__flex">
                                    <div class="repeater-field">
                                        <label>
											<?php echo $this->labels['price_month']; ?>
                                            <input type="number" class="widefat" name="wescle_tariff_slider_prices[price_month][]" value="<?php echo esc_attr( $item['price_month'] ); ?>">
                                        </label>
                                    </div>
                                    <div class="repeater-field">
                                        <label>
											<?php echo $this->labels['price_month_after']; ?>
                                            <input type="text" class="widefat" name="wescle_tariff_slider_prices[price_month_after][]" value="<?php echo esc_attr( $item['price_month_after'] ); ?>">
                                        </label>
                                    </div>
                                    <div class="repeater-field">
                                        <label>
											<?php echo $this->labels['url']; ?>
                                            <input type="text" class="widefat" name="wescle_tariff_slider_prices[url][]" value="<?php echo esc_attr( $item['url'] ); ?>">
                                        </label>
                                    </div>
                                    <div class="repeater-field">
                                        <label>
											<?php echo $this->labels['label_button']; ?>
                                            <input type="text" class="widefat" name="wescle_tariff_slider_prices[label_button][]" value="<?php echo esc_attr( $item['label_button'] ); ?>">
                                        </label>
                                    </div>
                                </div>
                                <div class="repeater-row__flex">
                                    <div class="repeater-field">
                                        <label>
											<?php echo $this->labels['price_year']; ?>
                                            <input type="number" class="widefat" name="wescle_tariff_slider_prices[price_year][]" value="<?php echo esc_attr( $item['price_year'] ); ?>">
                                        </label>
                                    </div>
                                    <div class="repeater-field">
                                        <label>
											<?php echo $this->labels['price_year_after']; ?>
                                            <input type="text" class="widefat" name="wescle_tariff_slider_prices[price_year_after][]" value="<?php echo esc_attr( $item['price_year_after'] ); ?>">
                                        </label>
                                    </div>
                                    <div class="repeater-field">
                                        <label>
											<?php echo $this->labels['url_year']; ?>
                                            <input type="text" class="widefat" name="wescle_tariff_slider_prices[url_year][]" value="<?php echo esc_attr( $item['url_year'] ); ?>">
                                        </label>
                                    </div>
                                    <div class="repeater-field">
                                        <label>
											<?php echo $this->labels['label_button_year']; ?>
                                            <input type="text" class="widefat" name="wescle_tariff_slider_prices[label_button_year][]" value="<?php echo esc_attr( $item['label_button_year'] ); ?>">
                                        </label>
                                    </div>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                    <div class="repeater-field-hidden">
                        <div class="repeater-row repeater-row__flex flex-wrap">
                            <div class="repeater-row__flex">
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['percent']; ?>
                                        <input type="number" class="widefat" name="wescle_tariff_slider_prices[percent][]" value="">
                                    </label>
                                </div>
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['value']; ?>
                                        <input type="number" class="widefat" name="wescle_tariff_slider_prices[value][]" value="">
                                    </label>
                                </div>
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['price_custom']; ?>
                                        <input type="text" class="widefat" name="wescle_tariff_slider_prices[price_custom][]" value="">
                                    </label>
                                </div>
                                <div class="repeater-field alignright">
                                    <button type="button" class="button-link button-link-delete"><?php echo $this->labels['button_remove']; ?></button>
                                </div>
                            </div>
                            <div class="repeater-row__flex">
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['price_month']; ?>
                                        <input type="number" class="widefat" name="wescle_tariff_slider_prices[price_month][]" value="">
                                    </label>
                                </div>
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['price_month_after']; ?>
                                        <input type="text" class="widefat" name="wescle_tariff_slider_prices[price_month_after][]" value="">
                                    </label>
                                </div>
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['url']; ?>
                                        <input type="text" class="widefat" name="wescle_tariff_slider_prices[url][]" value="">
                                    </label>
                                </div>
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['label_button']; ?>
                                        <input type="text" class="widefat" name="wescle_tariff_slider_prices[label_button][]" value="">
                                    </label>
                                </div>
                            </div>
                            <div class="repeater-row__flex">
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['price_year']; ?>
                                        <input type="number" class="widefat" name="wescle_tariff_slider_prices[price_year][]" value="">
                                    </label>
                                </div>
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['price_year_after']; ?>
                                        <input type="text" class="widefat" name="wescle_tariff_slider_prices[price_year_after][]" value="">
                                    </label>
                                </div>
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['url_year']; ?>
                                        <input type="text" class="widefat" name="wescle_tariff_slider_prices[url_year][]" value="">
                                    </label>
                                </div>
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['label_button_year']; ?>
                                        <input type="text" class="widefat" name="wescle_tariff_slider_prices[label_button_year][]" value="">
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button type="button" class="button-secondary repeater-add-item"><?php echo $this->labels['button_add_item']; ?></button>
            </div>
        </div>
		<?php
	}

	public function render_meta_box_content( $post ) {
		$wescle_tariff_info = get_post_meta( $post->ID, 'wescle_tariff_info', true );
		?>
        <div class="wescle-metabox">
			<?php wp_nonce_field( 'wescle_tariff_info', 'wescle_tariff_info_nonce' ); ?>

            <div class="wrap-repeater-fields">
                <div class="repeater-fields">
					<?php
					if ( $wescle_tariff_info ) {
						foreach ( $wescle_tariff_info as $item ) {
							?>
                            <div class="repeater-row repeater-row__flex">
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['type']; ?>
                                        <select class="widefat" name="wescle_tariff_info[type][]">
                                            <option value="plus" <?php selected( 'plus', $item['type'] ); ?>><?php echo $this->labels['type_plus']; ?></option>
                                            <option value="minus" <?php selected( 'minus', $item['type'] ); ?>><?php echo $this->labels['type_minus']; ?></option>
                                            <option value="custom" <?php selected( 'custom', $item['type'] ); ?>><?php echo $this->labels['type_text']; ?></option>
                                        </select>
                                    </label>
                                </div>
                                <div class="repeater-field">
                                    <label>
										<?php echo $this->labels['title']; ?>
                                        <input type="text" class="widefat" name="wescle_tariff_info[title][]" value="<?php echo esc_attr( $item['title'] ); ?>">
                                    </label>
                                </div>
                                <div class="repeater-field" style="width: 20%">
                                    <label>
										<?php echo $this->labels['text']; ?>
                                        <input type="text" class="widefat" name="wescle_tariff_info[text][]" value="<?php echo esc_attr( $item['text'] ); ?>">
                                    </label>
                                </div>
                                <div class="repeater-field alignright">
                                    <button type="button" class="button-link button-link-delete"><?php echo $this->labels['button_remove']; ?></button>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                    <div class="repeater-field-hidden">
                        <div class="repeater-row repeater-row__flex">
                            <div class="repeater-field">
                                <label>
									<?php echo $this->labels['type']; ?>
                                    <select class="widefat" name="wescle_tariff_info[type][]">
                                        <option value="plus"><?php echo $this->labels['type_plus']; ?></option>
                                        <option value="minus"><?php echo $this->labels['type_minus']; ?></option>
                                        <option value="custom"><?php echo $this->labels['type_text']; ?></option>
                                    </select>
                                </label>
                            </div>
                            <div class="repeater-field">
                                <label>
									<?php echo $this->labels['title']; ?>
                                    <input type="text" class="widefat" name="wescle_tariff_info[title][]" value="">
                                </label>
                            </div>
                            <div class="repeater-field" style="width: 20%">
                                <label>
									<?php echo $this->labels['text']; ?>
                                    <input type="text" class="widefat" name="wescle_tariff_info[text][]" value="">
                                </label>
                            </div>
                            <div class="repeater-field alignright">
                                <button type="button" class="button-link button-link-delete"><?php echo $this->labels['button_remove']; ?></button>
                            </div>
                        </div>
                    </div>
                </div>
                <button type="button" class="button-secondary repeater-add-item"><?php echo $this->labels['button_add_item']; ?></button>
            </div>
        </div>
		<?php
	}
}

new MetaBoxTariff();