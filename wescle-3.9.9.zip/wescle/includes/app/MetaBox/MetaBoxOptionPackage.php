<?php

class MetaBoxOptionPackage extends MetaBoxPost {

	public function __construct() {

		$this->fields = [
			[
				'type'  => 'price_package',
				'name'  => 'price_package_ids',
				'label' => esc_html__( 'Отметьте нужные пакеты', 'wescle' ),
			],
		];

		$this->set_settings( array(
			'post_type'      => [ 'optionpackage_wescle' ],
			'meta_box_title' => esc_html__( 'Настройки', 'wescle' ),
		) );

		if ( is_admin() ) {
			add_action( 'load-post.php', array( $this, 'init' ) );
			add_action( 'load-post-new.php', array( $this, 'init' ) );
		}
	}
}