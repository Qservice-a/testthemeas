<?php

class MetaBoxPriceList extends MetaBoxPost {

	public function __construct() {
		$this->fields = [
			[
				'type'  => 'checkbox',
				'name'  => 'is_open',
				'label' => esc_html__( 'Отображать блок сразу развернутым?', 'wescle' ),
			]
		];

		$this->set_settings( array(
			'post_type'      => [ 'price_wescle' ],
			'meta_box_title' => esc_html__( 'Настройки - Прайс', 'wescle' ),
		) );

		if ( is_admin() ) {
			add_action( 'load-post.php', array( $this, 'init' ) );
			add_action( 'load-post-new.php', array( $this, 'init' ) );
		}
	}
}