<?php
require_once get_template_directory() . '/libs/admin-notices/src/Dismiss.php';
require_once get_template_directory() . '/libs/admin-notices/src/Notice.php';
require_once get_template_directory() . '/libs/admin-notices/src/Notices.php';