<?php
$theme = wp_get_theme();
if ( $theme->parent() ) {
	$theme = $theme->parent();
}

define( 'THEME_VERSION', $theme->get( 'Version' ) );
define( 'THEME_SLUG', 'wescle' );
define( 'THEME_CONFIG_ID', THEME_SLUG . '_config_id' );
define( 'THEME_API_URL', 'https://wescle.com/wp-content/theme_license/api.php' );
define( 'THEME_UPDATE_URL', 'http://api.wescle.com' );